package com.prismatica.registry;

import com.prismatica.Prismatica;
import com.prismatica.item.*;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Rarity;

import java.util.ArrayList;
import java.util.List;

public final class ModItems {
    public static final List<Item> CONTENT = new ArrayList<>();
    public static final List<Item> SUBSTANCES = new ArrayList<>();

    // ---------- Materials ----------
    public static final Item PRISMITE_SHARD = reg("prismite_shard", new Item(new Item.Settings()));
    public static final Item SUNSTONE = reg("sunstone", new Item(new Item.Settings()));
    public static final Item VOID_CRYSTAL = reg("void_crystal", new Item(new Item.Settings().rarity(Rarity.UNCOMMON)));
    public static final Item STARLIGHT_ESSENCE = reg("starlight_essence", new Item(new Item.Settings().rarity(Rarity.UNCOMMON)) {
        @Override public boolean hasGlint(ItemStack stack) { return true; }
    });
    public static final Item BOTTLED_WISP = reg("bottled_wisp", new Throwables.BottledWispItem(new Item.Settings().maxCount(16).rarity(Rarity.UNCOMMON)));

    // ---------- Weapons & tools ----------
    public static final Item PRISMATIC_BLADE = reg("prismatic_blade", new Weapons.PrismaticBlade(ModToolMaterials.PRISMITE,
            new Item.Settings().rarity(Rarity.EPIC).attributeModifiers(SwordItem.createAttributeModifiers(ModToolMaterials.PRISMITE, 4, -2.2f))));
    public static final Item SOLAR_CLEAVER = reg("solar_cleaver", new Weapons.SolarCleaver(ModToolMaterials.SUNSTONE,
            new Item.Settings().rarity(Rarity.RARE).fireproof().attributeModifiers(SwordItem.createAttributeModifiers(ModToolMaterials.SUNSTONE, 5, -2.6f))));
    public static final Item VOID_REAPER = reg("void_reaper", new Weapons.VoidReaper(ModToolMaterials.VOIDCRYSTAL,
            new Item.Settings().rarity(Rarity.EPIC).attributeModifiers(SwordItem.createAttributeModifiers(ModToolMaterials.VOIDCRYSTAL, 4, -2.4f))));
    public static final Item PRISMITE_PICKAXE = reg("prismite_pickaxe", new OreSensePickaxeItem(ModToolMaterials.PRISMITE,
            new Item.Settings().rarity(Rarity.RARE).attributeModifiers(PickaxeItem.createAttributeModifiers(ModToolMaterials.PRISMITE, 1, -2.8f))));
    public static final Item PRISMITE_AXE = reg("prismite_axe", new AxeItem(ModToolMaterials.PRISMITE,
            new Item.Settings().rarity(Rarity.RARE).attributeModifiers(AxeItem.createAttributeModifiers(ModToolMaterials.PRISMITE, 6, -3.0f))));

    // ---------- Spells ----------
    public static final Item STARFALL_STAFF = reg("starfall_staff", new Spells.StarfallStaff(spell(Rarity.EPIC)));
    public static final Item BLINK_WAND = reg("blink_wand", new Spells.BlinkWand(spell(Rarity.RARE)));
    public static final Item STORM_SCEPTER = reg("storm_scepter", new Spells.StormScepter(spell(Rarity.EPIC)));
    public static final Item FROST_NOVA_WAND = reg("frost_nova_wand", new Spells.FrostNovaWand(spell(Rarity.RARE)));
    public static final Item SOLAR_BEAM_ROD = reg("solar_beam_rod", new Spells.SolarBeamRod(spell(Rarity.RARE).fireproof()));
    public static final Item AURORA_CHIME = reg("aurora_chime", new Spells.AuroraChime(spell(Rarity.EPIC)));
    public static final Item VORTEX_ORB = reg("vortex_orb", new Throwables.VortexOrbItem(new Item.Settings().maxCount(16).rarity(Rarity.RARE)));

    // ---------- Armor ----------
    public static final Item PRISMITE_HELMET = armor("prismite_helmet", ArmorItem.Type.HELMET);
    public static final Item PRISMITE_CHESTPLATE = armor("prismite_chestplate", ArmorItem.Type.CHESTPLATE);
    public static final Item PRISMITE_LEGGINGS = armor("prismite_leggings", ArmorItem.Type.LEGGINGS);
    public static final Item PRISMITE_BOOTS = armor("prismite_boots", ArmorItem.Type.BOOTS);

    // ---------- Spawn eggs ----------
    public static final Item PRISM_WISP_SPAWN_EGG = reg("prism_wisp_spawn_egg",
            new SpawnEggItem(ModEntities.PRISM_WISP, 0xF8BBD0, 0x80DEEA, new Item.Settings()));
    public static final Item THE_HOLLOW_SPAWN_EGG = reg("the_hollow_spawn_egg",
            new SpawnEggItem(ModEntities.THE_HOLLOW, 0x0D0D10, 0xE8E8E8, new Item.Settings()));

    // ---------- Substances (side feature) ----------
    public static final Item CANNABIS_SEEDS = sub("cannabis_seeds", new AliasedBlockItem(ModBlocks.CANNABIS_CROP, new Item.Settings()));
    public static final Item CANNABIS_BUD = sub("cannabis_bud", new Item(new Item.Settings()));

    public static final Item JOINT = sub("joint", new DrugItem(drug(ModEffects.CANNABIS, 1800,
            eff(StatusEffects.REGENERATION, 200, 0), eff(StatusEffects.HUNGER, 600, 0), eff(StatusEffects.SLOWNESS, 400, 0)),
            DrugItem.Style.SMOKE, null));
    public static final Item BLOTTER_TAB = sub("blotter_tab", new DrugItem(drug(ModEffects.LSD, 3600,
            eff(StatusEffects.SPEED, 1200, 0), eff(StatusEffects.NIGHT_VISION, 3600, 0)),
            DrugItem.Style.EAT, null));
    public static final Item MAGIC_MUSHROOM = sub("magic_mushroom", new DrugItem(drug(ModEffects.SHROOMS, 3000,
            eff(StatusEffects.NIGHT_VISION, 3000, 0), eff(StatusEffects.LUCK, 3000, 0)),
            DrugItem.Style.EAT, null));
    public static final Item PEYOTE_BUTTON = sub("peyote_button", new DrugItem(drug(ModEffects.MESCALINE, 3000,
            eff(StatusEffects.STRENGTH, 1200, 0), eff(StatusEffects.FIRE_RESISTANCE, 3000, 0)),
            DrugItem.Style.EAT, null));
    public static final Item KETAMINE = sub("ketamine", new DrugItem(drug(ModEffects.KETAMINE, 1200,
            eff(StatusEffects.SLOWNESS, 1200, 1), eff(StatusEffects.RESISTANCE, 1200, 1), eff(StatusEffects.SLOW_FALLING, 1200, 0)),
            DrugItem.Style.EAT, null));
    public static final Item SALVIA_LEAF = sub("salvia_leaf", new DrugItem(drug(ModEffects.SALVIA, 700,
            eff(StatusEffects.LEVITATION, 60, 0), eff(StatusEffects.WEAKNESS, 700, 0)),
            DrugItem.Style.SMOKE, null));
    public static final Item MOONSHINE = sub("moonshine", new DrugItem(drug(ModEffects.MOONSHINE, 2400,
            eff(StatusEffects.STRENGTH, 1200, 1), eff(StatusEffects.RESISTANCE, 1200, 0)),
            DrugItem.Style.DRINK, Items.GLASS_BOTTLE));
    public static final Item DMT = sub("dmt", new DmtItem(new Item.Settings().maxCount(16).rarity(Rarity.EPIC)
            .food(new FoodComponent.Builder().nutrition(0).saturationModifier(0f).alwaysEdible().build())));

    // ---------- helpers ----------
    private static Item.Settings spell(Rarity rarity) {
        return new Item.Settings().maxCount(1).rarity(rarity);
    }

    private static StatusEffectInstance eff(RegistryEntry<StatusEffect> e, int duration, int amp) {
        return new StatusEffectInstance(e, duration, amp, false, false, true);
    }

    private static Item.Settings drug(RegistryEntry<StatusEffect> trip, int duration, StatusEffectInstance... extras) {
        FoodComponent.Builder food = new FoodComponent.Builder().nutrition(1).saturationModifier(0.1f).alwaysEdible().snack()
                .statusEffect(new StatusEffectInstance(trip, duration, 0, false, false, true), 1.0f);
        for (StatusEffectInstance extra : extras) food.statusEffect(extra, 1.0f);
        return new Item.Settings().maxCount(16).food(food.build());
    }

    private static Item armor(String name, ArmorItem.Type type) {
        return reg(name, new ArmorItem(ModArmorMaterials.PRISMITE, type,
                new Item.Settings().rarity(Rarity.RARE).maxDamage(type.getMaxDamage(37))));
    }

    private static Item reg(String name, Item item) {
        Item i = Registry.register(Registries.ITEM, Prismatica.id(name), item);
        CONTENT.add(i);
        return i;
    }

    private static Item sub(String name, Item item) {
        Item i = Registry.register(Registries.ITEM, Prismatica.id(name), item);
        SUBSTANCES.add(i);
        return i;
    }

    public static void init() {}
}
