package com.prismatica.registry;

import com.prismatica.Prismatica;
import com.prismatica.entity.HollowEntity;
import com.prismatica.entity.PrismWispEntity;
import com.prismatica.entity.VortexOrbEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class ModEntities {
    public static final EntityType<HollowEntity> THE_HOLLOW = Registry.register(Registries.ENTITY_TYPE, Prismatica.id("the_hollow"),
            EntityType.Builder.create(HollowEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.7f, 3.6f)
                    .makeFireImmune()
                    .maxTrackingRange(10)
                    .build("the_hollow"));

    public static final EntityType<PrismWispEntity> PRISM_WISP = Registry.register(Registries.ENTITY_TYPE, Prismatica.id("prism_wisp"),
            EntityType.Builder.create(PrismWispEntity::new, SpawnGroup.AMBIENT)
                    .dimensions(0.5f, 0.5f)
                    .maxTrackingRange(8)
                    .build("prism_wisp"));

    public static final EntityType<VortexOrbEntity> VORTEX_ORB = Registry.register(Registries.ENTITY_TYPE, Prismatica.id("vortex_orb"),
            EntityType.Builder.<VortexOrbEntity>create(VortexOrbEntity::new, SpawnGroup.MISC)
                    .dimensions(0.3f, 0.3f)
                    .maxTrackingRange(6)
                    .trackingTickInterval(2)
                    .build("vortex_orb"));

    public static void init() {
        FabricDefaultAttributeRegistry.register(THE_HOLLOW, HollowEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(PRISM_WISP, PrismWispEntity.createAttributes());
    }
}
