package com.prismatica.registry;

import com.prismatica.Prismatica;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Util;

import java.util.EnumMap;
import java.util.List;

public final class ModArmorMaterials {
    public static final RegistryEntry<ArmorMaterial> PRISMITE = Registry.registerReference(Registries.ARMOR_MATERIAL, Prismatica.id("prismite"),
            new ArmorMaterial(
                    Util.make(new EnumMap<>(ArmorItem.Type.class), map -> {
                        map.put(ArmorItem.Type.BOOTS, 3);
                        map.put(ArmorItem.Type.LEGGINGS, 6);
                        map.put(ArmorItem.Type.CHESTPLATE, 8);
                        map.put(ArmorItem.Type.HELMET, 3);
                        map.put(ArmorItem.Type.BODY, 11);
                    }),
                    22,
                    SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND,
                    () -> Ingredient.ofItems(ModItems.PRISMITE_SHARD),
                    List.of(new ArmorMaterial.Layer(Prismatica.id("prismite"))),
                    2.5f,
                    0.05f));

    public static void init() {}
}
