package com.prismatica.registry;

import com.prismatica.Prismatica;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.world.World;

public final class ModDimensions {
    /** Defined in data/prismatica/dimension/the_house.json */
    public static final RegistryKey<World> THE_HOUSE = RegistryKey.of(RegistryKeys.WORLD, Prismatica.id("the_house"));

    private ModDimensions() {}
}
