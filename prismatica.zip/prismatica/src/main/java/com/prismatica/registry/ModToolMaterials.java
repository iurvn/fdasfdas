package com.prismatica.registry;

import net.minecraft.block.Block;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;

import java.util.function.Supplier;

public enum ModToolMaterials implements ToolMaterial {
    PRISMITE(1650, 9.0f, 3.5f, 22, BlockTags.INCORRECT_FOR_DIAMOND_TOOL, () -> Ingredient.ofItems(ModItems.PRISMITE_SHARD)),
    SUNSTONE(1400, 8.5f, 4.0f, 18, BlockTags.INCORRECT_FOR_DIAMOND_TOOL, () -> Ingredient.ofItems(ModItems.SUNSTONE)),
    VOIDCRYSTAL(2300, 10.0f, 5.0f, 15, BlockTags.INCORRECT_FOR_NETHERITE_TOOL, () -> Ingredient.ofItems(ModItems.VOID_CRYSTAL));

    private final int durability;
    private final float speed;
    private final float damage;
    private final int enchantability;
    private final TagKey<Block> inverseTag;
    private final Supplier<Ingredient> repair;

    ModToolMaterials(int durability, float speed, float damage, int enchantability, TagKey<Block> inverseTag, Supplier<Ingredient> repair) {
        this.durability = durability;
        this.speed = speed;
        this.damage = damage;
        this.enchantability = enchantability;
        this.inverseTag = inverseTag;
        this.repair = repair;
    }

    @Override public int getDurability() { return durability; }
    @Override public float getMiningSpeedMultiplier() { return speed; }
    @Override public float getAttackDamage() { return damage; }
    @Override public TagKey<Block> getInverseTag() { return inverseTag; }
    @Override public int getEnchantability() { return enchantability; }
    @Override public Ingredient getRepairIngredient() { return repair.get(); }
}
