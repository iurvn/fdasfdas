package com.prismatica.registry;

import com.prismatica.Prismatica;
import com.prismatica.effect.TripEffect;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;

/** Each substance is its own status effect; the client reads these to drive the screen shaders. */
public final class ModEffects {
    public static final RegistryEntry<StatusEffect> LSD = reg("lsd", 0xE040FB);
    public static final RegistryEntry<StatusEffect> SHROOMS = reg("shrooms", 0xA1887F);
    public static final RegistryEntry<StatusEffect> CANNABIS = reg("cannabis", 0x66BB6A);
    public static final RegistryEntry<StatusEffect> MESCALINE = reg("mescaline", 0xFFB74D);
    public static final RegistryEntry<StatusEffect> KETAMINE = reg("ketamine", 0x90CAF9);
    public static final RegistryEntry<StatusEffect> SALVIA = reg("salvia", 0x2E7D32);
    public static final RegistryEntry<StatusEffect> MOONSHINE = reg("moonshine", 0xFFD54F);
    public static final RegistryEntry<StatusEffect> BREAKTHROUGH = reg("breakthrough", 0xFFFFFF);

    private static RegistryEntry<StatusEffect> reg(String name, int color) {
        return Registry.registerReference(Registries.STATUS_EFFECT, Prismatica.id(name), new TripEffect(color));
    }

    public static void init() {}
}
