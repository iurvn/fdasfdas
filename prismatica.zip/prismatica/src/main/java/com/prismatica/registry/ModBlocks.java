package com.prismatica.registry;

import com.prismatica.Prismatica;
import com.prismatica.block.*;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.math.intprovider.UniformIntProvider;

import java.util.ArrayList;
import java.util.List;

public final class ModBlocks {
    /** Blocks that get a BlockItem, in creative-tab order. */
    public static final List<Block> WITH_ITEMS = new ArrayList<>();

    // --- Ores ---
    public static final Block PRISMITE_ORE = reg("prismite_ore", new FxOreBlock(UniformIntProvider.create(3, 7),
            AbstractBlock.Settings.copy(Blocks.DIAMOND_ORE).luminance(s -> 4), BlockFx.PRISMITE_ORE));
    public static final Block DEEPSLATE_PRISMITE_ORE = reg("deepslate_prismite_ore", new FxOreBlock(UniformIntProvider.create(3, 7),
            AbstractBlock.Settings.copy(Blocks.DEEPSLATE_DIAMOND_ORE).luminance(s -> 4), BlockFx.PRISMITE_ORE));
    public static final Block SUNSTONE_ORE = reg("sunstone_ore", new FxOreBlock(UniformIntProvider.create(2, 5),
            AbstractBlock.Settings.copy(Blocks.NETHER_GOLD_ORE).strength(3.0f).luminance(s -> 7), BlockFx.SUNSTONE_ORE));
    public static final Block VOIDCRYSTAL_ORE = reg("voidcrystal_ore", new FxOreBlock(UniformIntProvider.create(4, 9),
            AbstractBlock.Settings.copy(Blocks.END_STONE).strength(4.5f, 9f).requiresTool().luminance(s -> 5), BlockFx.VOID_ORE));

    // --- Storage blocks ---
    public static final Block PRISMITE_BLOCK = reg("prismite_block", new FxBlock(
            AbstractBlock.Settings.copy(Blocks.AMETHYST_BLOCK).strength(4f).requiresTool().luminance(s -> 10), BlockFx.PRISMITE));
    public static final Block SUNSTONE_BLOCK = reg("sunstone_block", new FxBlock(
            AbstractBlock.Settings.copy(Blocks.GOLD_BLOCK).luminance(s -> 15), BlockFx.SUNSTONE));
    public static final Block VOIDCRYSTAL_BLOCK = reg("voidcrystal_block", new FxBlock(
            AbstractBlock.Settings.copy(Blocks.OBSIDIAN).strength(8f, 1200f).luminance(s -> 6), BlockFx.VOID));

    // --- Decorative & functional ---
    public static final Block AURORA_LAMP = reg("aurora_lamp", new FxBlock(
            AbstractBlock.Settings.copy(Blocks.SEA_LANTERN).luminance(s -> 15), BlockFx.AURORA));
    public static final Block NEBULA_GLASS = reg("nebula_glass", new NebulaGlassBlock(
            AbstractBlock.Settings.copy(Blocks.TINTED_GLASS).luminance(s -> 5).nonOpaque()));
    public static final Block STARFIELD_BLOCK = reg("starfield_block", new FxBlock(
            AbstractBlock.Settings.copy(Blocks.BLACK_CONCRETE).luminance(s -> 3), BlockFx.STARFIELD));
    public static final Block SPIRIT_BRAZIER = reg("spirit_brazier", new FxBlock(
            AbstractBlock.Settings.copy(Blocks.LODESTONE).luminance(s -> 13).sounds(BlockSoundGroup.NETHERITE), BlockFx.BRAZIER));
    public static final Block BOUNCE_PAD = reg("bounce_pad", new PadBlock(
            AbstractBlock.Settings.copy(Blocks.SLIME_BLOCK).luminance(s -> 6), true));
    public static final Block SPEED_RUNE = reg("speed_rune", new PadBlock(
            AbstractBlock.Settings.copy(Blocks.POLISHED_DEEPSLATE).luminance(s -> 8), false));

    // --- Crop (seeds item registered in ModItems) ---
    public static final Block CANNABIS_CROP = Registry.register(Registries.BLOCK, Prismatica.id("cannabis_crop"),
            new CannabisCropBlock(AbstractBlock.Settings.copy(Blocks.WHEAT)));

    private static Block reg(String name, Block block) {
        Block b = Registry.register(Registries.BLOCK, Prismatica.id(name), block);
        Registry.register(Registries.ITEM, Prismatica.id(name), new BlockItem(b, new Item.Settings()));
        WITH_ITEMS.add(b);
        return b;
    }

    public static void init() {}
}
