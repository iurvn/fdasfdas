package com.prismatica.registry;

import com.prismatica.Prismatica;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;

public final class ModItemGroups {
    public static final ItemGroup MAIN = Registry.register(Registries.ITEM_GROUP, Prismatica.id("main"),
            FabricItemGroup.builder()
                    .icon(() -> new ItemStack(ModItems.PRISMATIC_BLADE))
                    .displayName(Text.translatable("itemGroup.prismatica.main"))
                    .entries((ctx, entries) -> {
                        for (Item i : ModItems.CONTENT) entries.add(i);
                        for (Block b : ModBlocks.WITH_ITEMS) entries.add(b);
                    })
                    .build());

    public static final ItemGroup SUBSTANCES = Registry.register(Registries.ITEM_GROUP, Prismatica.id("substances"),
            FabricItemGroup.builder()
                    .icon(() -> new ItemStack(ModItems.BLOTTER_TAB))
                    .displayName(Text.translatable("itemGroup.prismatica.substances"))
                    .entries((ctx, entries) -> {
                        for (Item i : ModItems.SUBSTANCES) entries.add(i);
                    })
                    .build());

    public static void init() {}
}
