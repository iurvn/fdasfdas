package com.prismatica.network;

import com.prismatica.Prismatica;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Server -> client: play the Hollow jumpscare. */
public record JumpscarePayload(int kind) implements CustomPayload {
    public static final CustomPayload.Id<JumpscarePayload> ID = new CustomPayload.Id<>(Prismatica.id("jumpscare"));
    public static final PacketCodec<RegistryByteBuf, JumpscarePayload> CODEC =
            PacketCodec.tuple(PacketCodecs.VAR_INT, JumpscarePayload::kind, JumpscarePayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
