package com.prismatica.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * A consumable substance. The status effects are attached through the item's food component
 * (see ModItems); this class only picks the animation, adds smoke and returns containers.
 */
public class DrugItem extends Item {
    public enum Style { EAT, DRINK, SMOKE }

    private final Style style;
    @Nullable private final Item remainder;

    public DrugItem(Settings settings, Style style, @Nullable Item remainder) {
        super(settings);
        this.style = style;
        this.remainder = remainder;
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return switch (style) {
            case EAT -> UseAction.EAT;
            case DRINK -> UseAction.DRINK;
            case SMOKE -> UseAction.TOOT_HORN; // holds it up to the mouth
        };
    }

    @Override
    public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
        ItemStack result = super.finishUsing(stack, world, user);
        if (world instanceof ServerWorld sw) {
            if (style == Style.SMOKE) {
                sw.spawnParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, user.getX(), user.getEyeY(), user.getZ(), 4, 0.15, 0.1, 0.15, 0.01);
                sw.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.PLAYERS, 0.4f, 1.6f);
            }
            sw.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_RESONATE, SoundCategory.PLAYERS, 0.6f,
                    0.6f + sw.random.nextFloat() * 0.6f);
            onConsumed(sw, user);
        }
        if (remainder != null && user instanceof PlayerEntity p && !p.getAbilities().creativeMode) {
            ItemStack r = new ItemStack(remainder);
            if (result.isEmpty()) return r;
            if (!p.getInventory().insertStack(r)) p.dropItem(r, false);
        }
        return result;
    }

    /** Hook for special substances. */
    protected void onConsumed(ServerWorld world, LivingEntity user) {}
}
