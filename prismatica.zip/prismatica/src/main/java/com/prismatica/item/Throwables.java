package com.prismatica.item;

import com.prismatica.entity.PrismWispEntity;
import com.prismatica.entity.VortexOrbEntity;
import com.prismatica.registry.ModEntities;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsage;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Small throwable/releasable items. */
public final class Throwables {
    private Throwables() {}

    /** Thrown orb that becomes a gravity well, sucking in mobs before imploding. */
    public static class VortexOrbItem extends Item {
        public VortexOrbItem(Settings s) { super(s); }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack stack = user.getStackInHand(hand);
            world.playSound(null, user.getX(), user.getY(), user.getZ(), SoundEvents.ENTITY_ENDER_PEARL_THROW, SoundCategory.PLAYERS, 0.7f, 0.5f);
            if (!world.isClient) {
                VortexOrbEntity orb = new VortexOrbEntity(world, user);
                orb.setItem(stack);
                orb.setVelocity(user, user.getPitch(), user.getYaw(), 0f, 1.4f, 0.5f);
                world.spawnEntity(orb);
            }
            user.getItemCooldownManager().set(this, 20);
            stack.decrementUnlessCreative(1, user);
            return TypedActionResult.success(stack, world.isClient());
        }
    }

    /** A captured Prism Wisp. Right-click to set it free (you keep the bottle). */
    public static class BottledWispItem extends Item {
        public BottledWispItem(Settings s) { super(s); }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
            ItemStack stack = user.getStackInHand(hand);
            if (!world.isClient) {
                PrismWispEntity wisp = ModEntities.PRISM_WISP.create(world);
                if (wisp != null) {
                    Vec3d p = user.getEyePos().add(user.getRotationVec(1f).multiply(1.5));
                    wisp.refreshPositionAndAngles(p.x, p.y, p.z, user.getYaw(), 0);
                    world.spawnEntity(wisp);
                }
                world.playSound(null, user.getBlockPos(), SoundEvents.ITEM_BOTTLE_EMPTY, SoundCategory.PLAYERS, 1f, 1.5f);
                world.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.PLAYERS, 1f, 2f);
            }
            ItemStack result = ItemUsage.exchangeStack(stack, user, new ItemStack(Items.GLASS_BOTTLE));
            return TypedActionResult.success(result, world.isClient());
        }
    }
}
