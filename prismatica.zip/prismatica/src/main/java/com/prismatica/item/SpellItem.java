package com.prismatica.item;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Base for right-click spell items: cooldown, glint, server-side cast. */
public abstract class SpellItem extends Item {
    private final int cooldown;

    protected SpellItem(Settings settings, int cooldownTicks) {
        super(settings);
        this.cooldown = cooldownTicks;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world instanceof ServerWorld sw) {
            if (!cast(sw, user, stack)) {
                return TypedActionResult.fail(stack);
            }
        }
        user.getItemCooldownManager().set(this, cooldown);
        return TypedActionResult.success(stack, world.isClient());
    }

    /** Runs on the server. Return false to cancel (no cooldown). */
    protected abstract boolean cast(ServerWorld world, PlayerEntity user, ItemStack stack);

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }
}
