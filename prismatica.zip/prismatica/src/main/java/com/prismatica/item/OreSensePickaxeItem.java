package com.prismatica.item;

import com.prismatica.registry.ModBlocks;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import com.prismatica.fx.Fx;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Right-click in the air to "sense" ores: colored particle threads point toward each vein. */
public class OreSensePickaxeItem extends PickaxeItem {
    private static final int RADIUS = 10;

    public OreSensePickaxeItem(ToolMaterial material, Settings settings) {
        super(material, settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world instanceof ServerWorld sw && user instanceof ServerPlayerEntity sp) {
            BlockPos origin = user.getBlockPos();
            List<BlockPos> found = new ArrayList<>();
            for (BlockPos p : BlockPos.iterate(origin.add(-RADIUS, -RADIUS, -RADIUS), origin.add(RADIUS, RADIUS, RADIUS))) {
                if (oreColor(world.getBlockState(p)) != 0) found.add(p.toImmutable());
            }
            found.sort(Comparator.comparingDouble(p -> p.getSquaredDistance(origin)));
            Vec3d eye = user.getEyePos();
            int shown = 0;
            for (BlockPos p : found) {
                if (shown++ >= 32) break;
                int color = oreColor(world.getBlockState(p));
                DustParticleEffect dust = Fx.dust(color, 1.0f);
                Vec3d target = Vec3d.ofCenter(p);
                Vec3d dir = target.subtract(eye).normalize();
                double len = Math.min(4.0, target.distanceTo(eye) - 0.5);
                for (double t = 0.8; t < len; t += 0.25) {
                    Vec3d q = eye.add(dir.multiply(t));
                    sw.spawnParticles(sp, dust, true, q.x, q.y, q.z, 1, 0, 0, 0, 0);
                }
                sw.spawnParticles(sp, dust, true, target.x, target.y, target.z, 8, 0.3, 0.3, 0.3, 0);
            }
            sp.sendMessage(Text.literal("Sensed " + found.size() + " ore blocks nearby").formatted(Formatting.LIGHT_PURPLE), true);
            world.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_RESONATE, SoundCategory.PLAYERS, 1f, 1.5f);
        }
        user.getItemCooldownManager().set(this, 100);
        return TypedActionResult.success(stack, world.isClient());
    }

    private static int oreColor(BlockState s) {
        if (s.isIn(BlockTags.DIAMOND_ORES)) return 0x4DD0E1;
        if (s.isIn(BlockTags.EMERALD_ORES)) return 0x00E676;
        if (s.isIn(BlockTags.GOLD_ORES)) return 0xFFD600;
        if (s.isIn(BlockTags.IRON_ORES)) return 0xD7CCC8;
        if (s.isIn(BlockTags.REDSTONE_ORES)) return 0xFF1744;
        if (s.isIn(BlockTags.LAPIS_ORES)) return 0x2962FF;
        if (s.isIn(BlockTags.COPPER_ORES)) return 0xFF7043;
        if (s.isIn(BlockTags.COAL_ORES)) return 0x424242;
        if (s.isOf(Blocks.ANCIENT_DEBRIS)) return 0x8D6E63;
        if (s.isOf(ModBlocks.PRISMITE_ORE) || s.isOf(ModBlocks.DEEPSLATE_PRISMITE_ORE)) return 0xE040FB;
        if (s.isOf(ModBlocks.SUNSTONE_ORE)) return 0xFFAB00;
        if (s.isOf(ModBlocks.VOIDCRYSTAL_ORE)) return 0x7C4DFF;
        return 0;
    }
}
