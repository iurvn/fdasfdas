package com.prismatica.item;

import com.prismatica.fx.Fx;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;

/** The three signature swords. */
public final class Weapons {
    private Weapons() {}

    /** Every hit bursts into a rainbow ring; 25% chance of a Prism Burst that hits everything nearby. */
    public static class PrismaticBlade extends SwordItem {
        public PrismaticBlade(ToolMaterial m, Settings s) { super(m, s); }

        @Override
        public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            if (attacker.getWorld() instanceof ServerWorld w) {
                float hue = (w.getTime() % 100) / 100f;
                Vec3d mid = target.getPos().add(0, target.getHeight() * 0.5, 0);
                Fx.rainbowRing(w, mid, 1.1, 30, hue, 1.1f);
                w.spawnParticles(ParticleTypes.END_ROD, mid.x, mid.y, mid.z, 10, 0.2, 0.3, 0.2, 0.15);
                if (attacker.getRandom().nextFloat() < 0.25f) {
                    for (int beam = 0; beam < 8; beam++) {
                        double a = beam * Math.PI / 4;
                        Fx.line(w, mid, mid.add(Math.cos(a) * 4, 0, Math.sin(a) * 4), 0.3, Fx.rainbowDust(hue + beam / 8f, 1.4f));
                    }
                    for (LivingEntity e : Fx.around(w, mid, 4, attacker)) {
                        if (e != target) e.damage(w.getDamageSources().indirectMagic(attacker, attacker), 6f);
                    }
                    w.playSound(null, target.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_BREAK, SoundCategory.PLAYERS, 1.2f, 0.8f);
                    w.playSound(null, target.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.PLAYERS, 1.5f, 1.2f);
                }
            }
            return super.postHit(stack, target, attacker);
        }
    }

    /** Sets targets ablaze with a flame pillar; 20% chance of a Solar Flash fire ring. */
    public static class SolarCleaver extends SwordItem {
        public SolarCleaver(ToolMaterial m, Settings s) { super(m, s); }

        @Override
        public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            if (attacker.getWorld() instanceof ServerWorld w) {
                target.setOnFireFor(5);
                Fx.spiral(w, target.getPos(), 0.8, target.getHeight() + 1, 24, 2, ParticleTypes.FLAME);
                if (attacker.getRandom().nextFloat() < 0.2f) {
                    Vec3d c = target.getPos().add(0, 0.2, 0);
                    for (double r = 1; r <= 3.5; r += 0.5) Fx.ring(w, c, r, (int) (r * 14), ParticleTypes.FLAME, 0.08);
                    w.spawnParticles(Fx.fade(0xFFF176, 0xFF3D00, 2.5f), c.x, c.y + 1, c.z, 40, 1.5, 0.5, 1.5, 0);
                    for (LivingEntity e : Fx.around(w, c, 3.5, attacker)) {
                        if (e != target) {
                            e.damage(w.getDamageSources().indirectMagic(attacker, attacker), 5f);
                            e.setOnFireFor(4);
                        }
                    }
                    w.playSound(null, target.getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 1.2f, 0.7f);
                }
            }
            return super.postHit(stack, target, attacker);
        }
    }

    /** Drains life from targets; 15% chance to open a rift that drags enemies in. */
    public static class VoidReaper extends SwordItem {
        public VoidReaper(ToolMaterial m, Settings s) { super(m, s); }

        @Override
        public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            if (attacker.getWorld() instanceof ServerWorld w) {
                attacker.heal(2.5f);
                target.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 60, 1));
                Vec3d from = target.getPos().add(0, target.getHeight() * 0.6, 0);
                Vec3d to = attacker.getPos().add(0, 1.2, 0);
                Fx.line(w, from, to, 0.35, Fx.fade(0xAA00FF, 0x1A0033, 1.2f));
                w.spawnParticles(ParticleTypes.SOUL, from.x, from.y, from.z, 6, 0.2, 0.3, 0.2, 0.03);
                if (attacker.getRandom().nextFloat() < 0.15f) {
                    w.spawnParticles(ParticleTypes.REVERSE_PORTAL, from.x, from.y, from.z, 120, 1.5, 1, 1.5, 0.3);
                    for (LivingEntity e : Fx.around(w, from, 6, attacker)) {
                        if (e == target) continue;
                        Vec3d pull = from.subtract(e.getPos()).normalize().multiply(0.8);
                        e.addVelocity(pull.x, 0.25, pull.z);
                        e.velocityModified = true;
                    }
                    w.playSound(null, target.getBlockPos(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.PLAYERS, 0.6f, 1.6f);
                }
            }
            return super.postHit(stack, target, attacker);
        }
    }
}
