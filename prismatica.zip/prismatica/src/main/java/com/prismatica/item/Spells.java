package com.prismatica.item;

import com.prismatica.fx.Fx;
import com.prismatica.fx.Scheduler;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.Set;

/** All the spell staves/wands in one place. */
public final class Spells {
    private Spells() {}

    /** Calls a meteor down from the sky onto where you're looking. */
    public static class StarfallStaff extends SpellItem {
        public StarfallStaff(Settings s) { super(s, 60); }

        @Override
        protected boolean cast(ServerWorld w, PlayerEntity user, ItemStack stack) {
            Vec3d target = user.raycast(48, 1f, false).getPos();
            Vec3d sky = target.add(7, 30, 7);
            w.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_EVOKER_CAST_SPELL, SoundCategory.PLAYERS, 1f, 0.7f);
            w.playSound(null, target.x, target.y, target.z, SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 2f, 0.5f);
            int steps = 18;
            for (int i = 0; i <= steps; i++) {
                final double t = i / (double) steps;
                Scheduler.schedule(i, () -> {
                    Vec3d p = sky.lerp(target, t);
                    w.spawnParticles(ParticleTypes.FLAME, p.x, p.y, p.z, 14, 0.35, 0.35, 0.35, 0.02);
                    w.spawnParticles(Fx.fade(0xFFFFFF, 0xFF6D00, 3.0f), p.x, p.y, p.z, 8, 0.3, 0.3, 0.3, 0);
                    w.spawnParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 3, 0.2, 0.2, 0.2, 0.05);
                    w.spawnParticles(ParticleTypes.LARGE_SMOKE, p.x, p.y + 0.5, p.z, 4, 0.2, 0.2, 0.2, 0.01);
                });
            }
            Scheduler.schedule(steps + 1, () -> impact(w, user, target));
            return true;
        }

        private static void impact(ServerWorld w, PlayerEntity user, Vec3d c) {
            w.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 1, 0, 0, 0, 0);
            w.spawnParticles(ParticleTypes.LAVA, c.x, c.y, c.z, 30, 1.5, 0.5, 1.5, 0);
            w.playSound(null, c.x, c.y, c.z, SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, SoundCategory.PLAYERS, 3f, 0.6f);
            w.playSound(null, c.x, c.y, c.z, SoundEvents.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, SoundCategory.PLAYERS, 3f, 0.8f);
            // Expanding shockwave rings
            for (int i = 0; i < 8; i++) {
                final double r = 0.8 + i * 0.7;
                final float hue = i / 8f;
                Scheduler.schedule(i, () -> {
                    Fx.rainbowRing(w, c.add(0, 0.2, 0), r, 40, hue, 1.6f);
                    Fx.ring(w, c.add(0, 0.1, 0), r, 20, ParticleTypes.FLAME, 0.05);
                });
            }
            for (LivingEntity e : Fx.around(w, c, 5.5, user)) {
                e.damage(w.getDamageSources().indirectMagic(user, user), 14f);
                e.setOnFireFor(5);
                Vec3d push = e.getPos().subtract(c).normalize().multiply(0.9);
                e.addVelocity(push.x, 0.7, push.z);
                e.velocityModified = true;
            }
        }
    }

    /** Short-range teleport with a rainbow slipstream. */
    public static class BlinkWand extends SpellItem {
        public BlinkWand(Settings s) { super(s, 25); }

        @Override
        protected boolean cast(ServerWorld w, PlayerEntity user, ItemStack stack) {
            Vec3d eye = user.getEyePos();
            Vec3d look = user.getRotationVec(1f);
            HitResult hit = user.raycast(24, 1f, false);
            Vec3d aim = hit.getType() == HitResult.Type.BLOCK ? hit.getPos().subtract(look.multiply(0.8)) : eye.add(look.multiply(24));
            Vec3d feet = aim.subtract(0, 1.0, 0);
            Vec3d dest = null;
            for (int i = 0; i < 6; i++) {
                Vec3d tryPos = feet.add(0, i * 0.5, 0);
                Box box = user.getBoundingBox().offset(tryPos.subtract(user.getPos()));
                if (w.isSpaceEmpty(user, box)) {
                    dest = tryPos;
                    break;
                }
            }
            if (dest == null) return false;
            Vec3d from = user.getPos();
            float hue = (w.getTime() % 60) / 60f;
            Vec3d a = from.add(0, 1, 0), b = dest.add(0, 1, 0);
            double len = a.distanceTo(b);
            for (double t = 0; t <= len; t += 0.4) {
                Vec3d p = a.lerp(b, t / len);
                w.spawnParticles(Fx.rainbowDust(hue + (float) (t / len), 1.3f), p.x, p.y, p.z, 2, 0.1, 0.1, 0.1, 0);
                w.spawnParticles(ParticleTypes.REVERSE_PORTAL, p.x, p.y, p.z, 1, 0.1, 0.1, 0.1, 0.02);
            }
            w.spawnParticles(ParticleTypes.PORTAL, from.x, from.y + 1, from.z, 60, 0.4, 0.8, 0.4, 0.4);
            w.playSound(null, from.x, from.y, from.z, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1f, 1.3f);
            user.requestTeleport(dest.x, dest.y, dest.z);
            user.fallDistance = 0;
            Fx.rainbowRing(w, dest.add(0, 0.1, 0), 1.0, 24, hue, 1.2f);
            w.playSound(null, dest.x, dest.y, dest.z, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1f, 1.6f);
            return true;
        }
    }

    /** Triple lightning barrage wrapped in an electric spiral. */
    public static class StormScepter extends SpellItem {
        public StormScepter(Settings s) { super(s, 80); }

        @Override
        protected boolean cast(ServerWorld w, PlayerEntity user, ItemStack stack) {
            Vec3d target = user.raycast(64, 1f, false).getPos();
            Fx.spiral(w, target, 2.5, 12, 60, 3, ParticleTypes.ELECTRIC_SPARK);
            w.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_ILLUSIONER_CAST_SPELL, SoundCategory.PLAYERS, 1f, 1.2f);
            for (int i = 0; i < 3; i++) {
                final int n = i;
                Scheduler.schedule(8 + i * 7, () -> {
                    LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(w);
                    if (bolt == null) return;
                    double ox = n == 0 ? 0 : (w.random.nextDouble() - 0.5) * 5;
                    double oz = n == 0 ? 0 : (w.random.nextDouble() - 0.5) * 5;
                    bolt.refreshPositionAfterTeleport(target.add(ox, 0, oz));
                    if (user instanceof ServerPlayerEntity sp) bolt.setChanneler(sp);
                    w.spawnEntity(bolt);
                    Fx.ring(w, target.add(ox, 0.2, oz), 1.5, 24, ParticleTypes.ELECTRIC_SPARK, 0.2);
                });
            }
            return true;
        }
    }

    /** Freezing shockwave around the caster. */
    public static class FrostNovaWand extends SpellItem {
        public FrostNovaWand(Settings s) { super(s, 70); }

        @Override
        protected boolean cast(ServerWorld w, PlayerEntity user, ItemStack stack) {
            Vec3d c = user.getPos().add(0, 0.2, 0);
            w.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.PLAYERS, 1.2f, 0.5f);
            w.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_PLAYER_HURT_FREEZE, SoundCategory.PLAYERS, 1.2f, 0.7f);
            for (int i = 0; i < 10; i++) {
                final double r = 0.8 + i * 0.8;
                Scheduler.schedule(i, () -> {
                    Fx.ring(w, c, r, (int) (r * 12), ParticleTypes.SNOWFLAKE, 0.05);
                    Fx.ring(w, c.add(0, 0.4, 0), r, (int) (r * 6), Fx.fade(0xFFFFFF, 0x4FC3F7, 1.4f), 0);
                });
            }
            for (LivingEntity e : Fx.around(w, c, 8, user)) {
                e.damage(w.getDamageSources().freeze(), 6f);
                e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 120, 3));
                e.setFrozenTicks(e.getMinFreezeDamageTicks() + 140);
                w.spawnParticles(ParticleTypes.ITEM_SNOWBALL, e.getX(), e.getBodyY(0.5), e.getZ(), 20, 0.3, 0.5, 0.3, 0.1);
            }
            return true;
        }
    }

    /** A searing beam of sunlight that pierces everything in a line. */
    public static class SolarBeamRod extends SpellItem {
        public SolarBeamRod(Settings s) { super(s, 45); }

        @Override
        protected boolean cast(ServerWorld w, PlayerEntity user, ItemStack stack) {
            Vec3d start = user.getEyePos().subtract(0, 0.2, 0);
            Vec3d end = user.raycast(32, 1f, false).getPos();
            Vec3d dir = end.subtract(start);
            double len = dir.length();
            if (len < 0.5) return false;
            Vec3d n = dir.normalize();
            Set<LivingEntity> hit = new HashSet<>();
            for (double t = 1; t <= len; t += 0.4) {
                Vec3d p = start.add(n.multiply(t));
                w.spawnParticles(Fx.fade(0xFFF59D, 0xFF3D00, 1.5f), p.x, p.y, p.z, 2, 0.05, 0.05, 0.05, 0);
                if (((int) (t * 10)) % 12 == 0) w.spawnParticles(ParticleTypes.FLAME, p.x, p.y, p.z, 2, 0.1, 0.1, 0.1, 0.02);
                hit.addAll(Fx.around(w, p, 1.2, user));
            }
            w.spawnParticles(ParticleTypes.EXPLOSION, end.x, end.y, end.z, 3, 0.3, 0.3, 0.3, 0);
            w.spawnParticles(ParticleTypes.LAVA, end.x, end.y, end.z, 10, 0.3, 0.3, 0.3, 0);
            for (LivingEntity e : hit) {
                e.damage(w.getDamageSources().indirectMagic(user, user), 9f);
                e.setOnFireFor(6);
            }
            w.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 1f, 1.4f);
            w.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, SoundCategory.PLAYERS, 1f, 1.8f);
            return true;
        }
    }

    /** Rings out an aurora that heals you and nearby players. */
    public static class AuroraChime extends SpellItem {
        public AuroraChime(Settings s) { super(s, 300); }

        @Override
        protected boolean cast(ServerWorld w, PlayerEntity user, ItemStack stack) {
            Vec3d c = user.getPos();
            w.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.PLAYERS, 2f, 0.6f);
            w.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_BELL_RESONATE, SoundCategory.PLAYERS, 1f, 1.4f);
            for (int tick = 0; tick < 30; tick += 2) {
                final int t = tick;
                Scheduler.schedule(tick, () -> {
                    for (int i = 0; i < 36; i++) {
                        double a = i * Math.PI * 2 / 36 + t * 0.05;
                        double wave = Math.sin(a * 3 + t * 0.3) * 0.6;
                        for (int h = 0; h < 6; h++) {
                            int from = h < 3 ? 0x00E676 : 0x40C4FF;
                            int to = h < 3 ? 0x1DE9B6 : 0xD500F9;
                            w.spawnParticles(Fx.fade(from, to, 1.2f), c.x + Math.cos(a) * 4.5, c.y + 1.5 + h * 0.7 + wave,
                                    c.z + Math.sin(a) * 4.5, 1, 0, 0.05, 0, 0);
                        }
                    }
                });
            }
            for (PlayerEntity p : w.getEntitiesByClass(PlayerEntity.class, Box.of(c, 20, 10, 20), p -> p.squaredDistanceTo(c) < 100)) {
                p.heal(8f);
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 120, 1));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 600, 0));
                w.spawnParticles(ParticleTypes.HEART, p.getX(), p.getY() + 2.2, p.getZ(), 5, 0.4, 0.2, 0.4, 0);
            }
            return true;
        }
    }
}
