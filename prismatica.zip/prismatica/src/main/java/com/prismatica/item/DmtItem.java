package com.prismatica.item;

import com.prismatica.dmt.DmtTripManager;
import com.prismatica.registry.ModDimensions;
import net.minecraft.entity.LivingEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Breaks through. Pulls the player into The House. */
public class DmtItem extends DrugItem {
    public DmtItem(Settings settings) {
        super(settings, Style.SMOKE, null);
    }

    @Override
    protected void onConsumed(ServerWorld world, LivingEntity user) {
        if (!(user instanceof ServerPlayerEntity player)) return;
        if (world.getRegistryKey().equals(ModDimensions.THE_HOUSE)) {
            player.sendMessage(Text.literal("You are already here.").formatted(Formatting.DARK_RED, Formatting.ITALIC), true);
            return;
        }
        DmtTripManager.startTrip(player);
    }
}
