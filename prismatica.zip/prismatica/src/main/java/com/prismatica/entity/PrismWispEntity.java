package com.prismatica.entity;

import com.prismatica.fx.Fx;
import com.prismatica.registry.ModItems;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * A small floating ball of light that drifts through the world trailing colored sparks.
 * Catch it in a glass bottle. Comes in three colors.
 */
public class PrismWispEntity extends PathAwareEntity {
    private static final TrackedData<Integer> VARIANT = DataTracker.registerData(PrismWispEntity.class, TrackedDataHandlerRegistry.INTEGER);
    public static final int[] COLORS = {0xFF80AB, 0x80DEEA, 0xFFE57F};

    @Nullable private Vec3d wanderTarget;

    public PrismWispEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
        this.setNoGravity(true);
        if (!world.isClient) this.dataTracker.set(VARIANT, world.random.nextInt(3));
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 6.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
                .add(EntityAttributes.GENERIC_FLYING_SPEED, 0.4);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(VARIANT, 0);
    }

    public int getVariant() {
        return Math.floorMod(this.dataTracker.get(VARIANT), 3);
    }

    @Override
    public void tick() {
        super.tick();
        World w = getWorld();
        if (w.isClient) {
            int color = COLORS[getVariant()];
            if (age % 2 == 0) {
                w.addParticle(Fx.dust(color, 0.7f), getX() + (random.nextDouble() - 0.5) * 0.3, getY() + 0.25,
                        getZ() + (random.nextDouble() - 0.5) * 0.3, 0, 0, 0);
            }
            if (random.nextInt(12) == 0) w.addParticle(ParticleTypes.END_ROD, getX(), getY() + 0.25, getZ(), 0, -0.01, 0);
            return;
        }
        // Server: gentle random drift like a firefly
        if (wanderTarget == null || squaredDistanceTo(wanderTarget) < 1.0 || random.nextInt(100) == 0) {
            for (int i = 0; i < 6; i++) {
                Vec3d t = getPos().add((random.nextDouble() - 0.5) * 12, (random.nextDouble() - 0.4) * 5, (random.nextDouble() - 0.5) * 12);
                BlockPos bp = BlockPos.ofFloored(t);
                if (w.isAir(bp) && w.isAir(bp.up())) {
                    wanderTarget = t;
                    break;
                }
            }
        }
        if (wanderTarget != null) {
            Vec3d d = wanderTarget.subtract(getPos()).normalize().multiply(0.025);
            Vec3d bob = new Vec3d(0, Math.sin(age * 0.15) * 0.008, 0);
            setVelocity(getVelocity().multiply(0.9).add(d).add(bob));
            Vec3d v = getVelocity();
            setYaw((float) (Math.atan2(v.z, v.x) * 180 / Math.PI) - 90f);
            bodyYaw = getYaw();
        }
    }

    @Override
    protected ActionResult interactMob(PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (stack.isOf(Items.GLASS_BOTTLE)) {
            if (!getWorld().isClient) {
                stack.decrementUnlessCreative(1, player);
                ItemStack bottled = new ItemStack(ModItems.BOTTLED_WISP);
                if (!player.getInventory().insertStack(bottled)) player.dropItem(bottled, false);
                playSound(SoundEvents.ITEM_BOTTLE_FILL, 1f, 1.4f);
                discard();
            }
            return ActionResult.success(getWorld().isClient);
        }
        return super.interactMob(player, hand);
    }

    @Override
    public boolean handleFallDamage(float fallDistance, float damageMultiplier, DamageSource damageSource) {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return random.nextInt(3) == 0 ? SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME : null;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.BLOCK_AMETHYST_CLUSTER_HIT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.BLOCK_AMETHYST_CLUSTER_BREAK;
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("Variant", getVariant());
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        this.dataTracker.set(VARIANT, nbt.getInt("Variant"));
    }
}
