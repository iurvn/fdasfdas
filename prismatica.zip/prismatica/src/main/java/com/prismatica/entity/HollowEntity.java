package com.prismatica.entity;

import com.prismatica.dmt.DmtTripManager;
import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * THE HOLLOW HOST.
 * A gaunt, 3.7-block-tall figure with arms that hang past its knees and a face that is mostly mouth.
 * It freezes while you look at it. The moment you look away, it moves. If it touches you, you wake up.
 * Hitting it does nothing - it just appears behind you.
 */
public class HollowEntity extends HostileEntity {
    private static final TrackedData<Boolean> WATCHED = DataTracker.registerData(HollowEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    @Nullable private UUID targetPlayer;
    private int lurkTicks = 100;
    private int watchedTicks;
    private int stuckTicks;
    private double lastDist = Double.MAX_VALUE;
    private int breathCooldown = 60;
    private boolean caught;

    public HollowEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 0;
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 666.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.34)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 0.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 64.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(WATCHED, false);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
    }

    public boolean isWatched() {
        return this.dataTracker.get(WATCHED);
    }

    public void setTargetPlayer(UUID uuid) {
        this.targetPlayer = uuid;
    }

    public void setLurkTicks(int ticks) {
        this.lurkTicks = ticks;
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld() instanceof ServerWorld sw) serverTick(sw);
    }

    private void serverTick(ServerWorld w) {
        if (caught) return;
        PlayerEntity target = targetPlayer != null ? w.getPlayerByUuid(targetPlayer) : w.getClosestPlayer(this, 48);
        if (target == null || !target.isAlive() || target.isSpectator()) {
            getNavigation().stop();
            if (targetPlayer != null) discard(); // its player left
            return;
        }

        double dist = distanceTo(target);
        boolean watched = isBeingWatchedBy(target);
        this.dataTracker.set(WATCHED, watched);
        getLookControl().lookAt(target, 10f, 10f);

        if (lurkTicks > 0) {
            lurkTicks--;
            getNavigation().stop();
            return;
        }

        if (watched && dist > 1.4) {
            // Statue. But it doesn't like being stared at for long.
            getNavigation().stop();
            setVelocity(0, getVelocity().y, 0);
            watchedTicks++;
            if (watchedTicks > 70 && random.nextFloat() < 0.03f) {
                vanish(w);
                teleportBehind(w, target, 3);
                watchedTicks = 0;
            }
        } else {
            watchedTicks = 0;
            getNavigation().startMovingTo(target, dist > 7 ? 1.7 : 1.2);
            if (dist >= lastDist - 0.02) stuckTicks++; else stuckTicks = 0;
            if (stuckTicks > 70) {
                teleportBehind(w, target, 4);
                stuckTicks = 0;
            }
            if (--breathCooldown <= 0 && dist < 12) {
                w.playSound(null, getX(), getEyeY(), getZ(), SoundEvents.ENTITY_ENDERMAN_AMBIENT, SoundCategory.HOSTILE, 0.8f, 0.35f);
                breathCooldown = 60 + random.nextInt(80);
            }
        }
        lastDist = dist;

        if (dist < 1.6) {
            caught = true;
            getNavigation().stop();
            if (target instanceof ServerPlayerEntity sp) DmtTripManager.onCaught(sp, this);
        }
    }

    public boolean isBeingWatchedBy(PlayerEntity p) {
        Vec3d look = p.getRotationVec(1.0f).normalize();
        Vec3d to = new Vec3d(getX() - p.getX(), getBodyY(0.75) - p.getEyeY(), getZ() - p.getZ());
        double len = to.length();
        if (len < 1e-3) return true;
        double dot = look.dotProduct(to.multiply(1.0 / len));
        // Narrower cone when far away, wider up close
        double threshold = MathHelper.clamp(0.55 + len * 0.012, 0.55, 0.85);
        return dot > threshold && p.canSee(this);
    }

    /** Puts the Hollow a few blocks directly behind the player, if there's room. */
    public boolean teleportBehind(ServerWorld w, PlayerEntity p, int maxDist) {
        Vec3d look = p.getRotationVec(1f);
        Vec3d back = new Vec3d(-look.x, 0, -look.z);
        if (back.lengthSquared() < 1e-4) back = new Vec3d(0, 0, 1);
        back = back.normalize();
        for (int d = maxDist; d >= 2; d--) {
            Vec3d pos = p.getPos().add(back.multiply(d));
            BlockPos bp = BlockPos.ofFloored(pos.x, p.getY(), pos.z);
            if (canStandAt(w, bp)) {
                refreshPositionAndAngles(pos.x, bp.getY(), pos.z, p.getYaw(), 0);
                getNavigation().stop();
                w.spawnParticles(ParticleTypes.SQUID_INK, getX(), getBodyY(0.5), getZ(), 20, 0.3, 1.0, 0.3, 0.01);
                w.playSound(null, getX(), getY(), getZ(), SoundEvents.ENTITY_WARDEN_HEARTBEAT, SoundCategory.HOSTILE, 1.5f, 0.6f);
                lastDist = Double.MAX_VALUE;
                return true;
            }
        }
        return false;
    }

    private void vanish(ServerWorld w) {
        w.spawnParticles(ParticleTypes.LARGE_SMOKE, getX(), getBodyY(0.5), getZ(), 30, 0.3, 1.2, 0.3, 0.01);
        w.spawnParticles(ParticleTypes.SQUID_INK, getX(), getBodyY(0.5), getZ(), 30, 0.3, 1.2, 0.3, 0.02);
    }

    private boolean canStandAt(ServerWorld w, BlockPos bp) {
        BlockState below = w.getBlockState(bp.down());
        if (below.getCollisionShape(w, bp.down()).isEmpty()) return false;
        for (int i = 0; i < 4; i++) {
            if (!w.getBlockState(bp.up(i)).getCollisionShape(w, bp.up(i)).isEmpty()) return false;
        }
        return true;
    }

    public void faceTowards(PlayerEntity p) {
        double dx = p.getX() - getX(), dz = p.getZ() - getZ();
        float yaw = (float) (MathHelper.atan2(dz, dx) * (180 / Math.PI)) - 90f;
        setYaw(yaw);
        setHeadYaw(yaw);
        setBodyYaw(yaw);
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (source.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.damage(source, amount);
        if (getWorld() instanceof ServerWorld w && source.getAttacker() instanceof PlayerEntity p) {
            vanish(w);
            teleportBehind(w, p, 3);
        }
        return false;
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    @Override
    protected boolean isDisallowedInPeaceful() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        // Silent.
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return null;
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        if (targetPlayer != null) nbt.putUuid("TargetPlayer", targetPlayer);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.containsUuid("TargetPlayer")) targetPlayer = nbt.getUuid("TargetPlayer");
    }
}
