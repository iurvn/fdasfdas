package com.prismatica.entity;

import com.prismatica.fx.Fx;
import com.prismatica.registry.ModEntities;
import com.prismatica.registry.ModItems;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Flies like a snowball; on impact it hangs in the air as a gravity well for 4 seconds, then implodes. */
public class VortexOrbEntity extends ThrownItemEntity {
    private static final int LIFETIME = 80;
    private int vortexTicks = -1;

    public VortexOrbEntity(EntityType<? extends VortexOrbEntity> type, World world) {
        super(type, world);
    }

    public VortexOrbEntity(World world, LivingEntity owner) {
        super(ModEntities.VORTEX_ORB, owner, world);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.VORTEX_ORB;
    }

    @Override
    protected void onCollision(HitResult hitResult) {
        if (getWorld().isClient || vortexTicks >= 0) return;
        vortexTicks = 0;
        setVelocity(Vec3d.ZERO);
        setNoGravity(true);
        getWorld().playSound(null, getX(), getY(), getZ(), SoundEvents.BLOCK_PORTAL_TRIGGER, SoundCategory.PLAYERS, 0.6f, 1.8f);
    }

    @Override
    public void tick() {
        if (vortexTicks >= 0) setVelocity(Vec3d.ZERO);
        super.tick();
        if (!(getWorld() instanceof ServerWorld w) || vortexTicks < 0) return;

        vortexTicks++;
        Vec3d c = getPos();
        double spin = vortexTicks * 0.35;
        // Three spiraling arms being sucked into the core
        for (int arm = 0; arm < 3; arm++) {
            for (int k = 0; k < 6; k++) {
                double r = 0.4 + k * 0.6;
                double a = spin + arm * (Math.PI * 2 / 3) + k * 0.5;
                w.spawnParticles(Fx.rainbowDust(arm / 3f + vortexTicks * 0.01f, 1.0f),
                        c.x + Math.cos(a) * r, c.y + Math.sin(k + spin) * 0.3, c.z + Math.sin(a) * r, 1, 0, 0, 0, 0);
            }
        }
        w.spawnParticles(ParticleTypes.REVERSE_PORTAL, c.x, c.y, c.z, 6, 0.1, 0.1, 0.1, 0.05);

        Entity owner = getOwner();
        for (LivingEntity e : Fx.around(w, c, 8, owner instanceof LivingEntity le ? le : null)) {
            Vec3d pull = c.subtract(e.getPos().add(0, e.getHeight() * 0.5, 0));
            double dist = Math.max(0.5, pull.length());
            Vec3d force = pull.normalize().multiply(0.18 + 0.4 / dist);
            e.addVelocity(force.x, force.y * 0.6 + 0.02, force.z);
            e.velocityModified = true;
            e.fallDistance = 0;
            if (vortexTicks % 10 == 0 && dist < 2.5) {
                e.damage(w.getDamageSources().indirectMagic(this, owner), 3f);
            }
        }
        if (vortexTicks % 20 == 0) {
            w.playSound(null, c.x, c.y, c.z, SoundEvents.BLOCK_BEACON_AMBIENT, SoundCategory.PLAYERS, 1.5f, 1.8f);
        }

        if (vortexTicks >= LIFETIME) {
            w.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 1, 0, 0, 0, 0);
            w.spawnParticles(ParticleTypes.END_ROD, c.x, c.y, c.z, 80, 0.2, 0.2, 0.2, 0.6);
            Fx.rainbowRing(w, c, 3, 48, 0f, 2f);
            w.playSound(null, c.x, c.y, c.z, SoundEvents.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, SoundCategory.PLAYERS, 2f, 0.5f);
            for (LivingEntity e : Fx.around(w, c, 4, owner instanceof LivingEntity le ? le : null)) {
                e.damage(w.getDamageSources().indirectMagic(this, owner), 8f);
                Vec3d push = e.getPos().subtract(c).normalize().multiply(1.2);
                e.addVelocity(push.x, 0.6, push.z);
                e.velocityModified = true;
            }
            discard();
        }
    }
}
