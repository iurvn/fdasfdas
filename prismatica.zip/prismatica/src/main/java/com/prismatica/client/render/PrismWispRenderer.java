package com.prismatica.client.render;

import com.prismatica.Prismatica;
import com.prismatica.entity.PrismWispEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

public class PrismWispRenderer extends MobEntityRenderer<PrismWispEntity, PrismWispModel> {
    private static final Identifier[] TEXTURES = {
            Prismatica.id("textures/entity/prism_wisp_rose.png"),
            Prismatica.id("textures/entity/prism_wisp_cyan.png"),
            Prismatica.id("textures/entity/prism_wisp_gold.png")
    };

    public PrismWispRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PrismWispModel(ctx.getPart(PrismWispModel.LAYER)), 0.15f);
    }

    @Override
    public Identifier getTexture(PrismWispEntity entity) {
        return TEXTURES[entity.getVariant()];
    }

    /** Wisps are their own light source. */
    @Override
    protected int getBlockLight(PrismWispEntity entity, BlockPos pos) {
        return 15;
    }
}
