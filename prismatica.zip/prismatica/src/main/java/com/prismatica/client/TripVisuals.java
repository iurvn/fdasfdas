package com.prismatica.client;

import com.prismatica.Prismatica;
import com.prismatica.entity.HollowEntity;
import com.prismatica.fx.Fx;
import com.prismatica.registry.ModDimensions;
import com.prismatica.registry.ModEffects;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.MathHelper;
import org.ladysnake.satin.api.event.ShaderEffectRenderCallback;
import org.ladysnake.satin.api.managed.ManagedShaderEffect;
import org.ladysnake.satin.api.managed.ShaderEffectManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Client-side trip engine. Each substance maps to its own post-processing shader
 * (assets/prismatica/shaders/post/*.json) plus camera drift, particles and sounds.
 *
 * Shader uniforms we drive:
 *   Clock      seconds since game start (vanilla already owns "Time", so we don't use that name)
 *   Intensity  0..1+ fade in/out based on the effect's remaining duration
 *   Dread      (house shader only) how close the Hollow is
 */
public final class TripVisuals {
    private TripVisuals() {}

    private record Trip(RegistryEntry<StatusEffect> effect, ManagedShaderEffect shader) {}

    private static final List<Trip> TRIPS = new ArrayList<>();
    private static final Map<RegistryEntry<StatusEffect>, Integer> ACTIVE_TICKS = new HashMap<>();
    private static ManagedShaderEffect houseShader;
    private static int clientTicks;
    private static float dread;

    private static ManagedShaderEffect load(String name) {
        return ShaderEffectManager.getInstance().manage(Prismatica.id("shaders/post/" + name + ".json"));
    }

    public static void init() {
        TRIPS.add(new Trip(ModEffects.MOONSHINE, load("moonshine")));
        TRIPS.add(new Trip(ModEffects.CANNABIS, load("cannabis")));
        TRIPS.add(new Trip(ModEffects.KETAMINE, load("ketamine")));
        TRIPS.add(new Trip(ModEffects.MESCALINE, load("mescaline")));
        TRIPS.add(new Trip(ModEffects.SHROOMS, load("shrooms")));
        TRIPS.add(new Trip(ModEffects.LSD, load("lsd")));
        TRIPS.add(new Trip(ModEffects.SALVIA, load("salvia")));
        TRIPS.add(new Trip(ModEffects.BREAKTHROUGH, load("breakthrough")));
        houseShader = load("the_house");

        ClientTickEvents.END_CLIENT_TICK.register(TripVisuals::tick);
        ShaderEffectRenderCallback.EVENT.register(tickDelta -> render());
    }

    // ------------------------------------------------------------------ rendering

    private static void render() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null) return;
        float delta = c.getRenderTickCounter().getTickDelta(false);
        float clock = (clientTicks + delta) / 20f;

        for (Trip t : TRIPS) {
            float i = intensity(c.player, t.effect);
            if (i <= 0.001f) continue;
            t.shader.setUniformValue("Clock", clock);
            t.shader.setUniformValue("Intensity", i);
            t.shader.render(delta);
        }
        if (inHouse(c)) {
            houseShader.setUniformValue("Clock", clock);
            houseShader.setUniformValue("Intensity", 1.0f);
            houseShader.setUniformValue("Dread", dread);
            houseShader.render(delta);
        }
    }

    private static boolean inHouse(MinecraftClient c) {
        return c.world != null && c.world.getRegistryKey().equals(ModDimensions.THE_HOUSE);
    }

    /** 0 when inactive, ramps in over 4s, fades out over the last 5s, stronger with higher amplifiers. */
    private static float intensity(ClientPlayerEntity p, RegistryEntry<StatusEffect> effect) {
        StatusEffectInstance inst = p.getStatusEffect(effect);
        if (inst == null) return 0f;
        if (effect == ModEffects.BREAKTHROUGH) {
            // Breakthrough builds all the way to a white-out
            return MathHelper.clamp(ACTIVE_TICKS.getOrDefault(effect, 0) / 65f, 0f, 1f);
        }
        float fadeIn = Math.min(1f, ACTIVE_TICKS.getOrDefault(effect, 0) / 80f);
        float fadeOut = inst.isInfinite() ? 1f : Math.min(1f, inst.getDuration() / 100f);
        return Math.min(fadeIn, fadeOut) * (1f + 0.3f * inst.getAmplifier());
    }

    // ------------------------------------------------------------------ per-tick camera, particles, sounds

    private static void tick(MinecraftClient c) {
        clientTicks++;
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null) {
            ACTIVE_TICKS.clear();
            return;
        }
        for (Trip t : TRIPS) {
            if (p.hasStatusEffect(t.effect)) ACTIVE_TICKS.merge(t.effect, 1, Integer::sum);
            else ACTIVE_TICKS.remove(t.effect);
        }
        if (c.isPaused()) return;

        float t = clientTicks / 20f;
        var r = p.getRandom();

        // --- Moonshine: heavy drunken sway
        float moon = intensity(p, ModEffects.MOONSHINE);
        if (moon > 0) {
            turn(p, MathHelper.sin(t * 1.1f) * 0.9f * moon, MathHelper.cos(t * 1.7f) * 0.45f * moon);
            if (r.nextInt(120) == 0) c.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ENTITY_PLAYER_BURP, 0.8f + r.nextFloat() * 0.3f, 0.6f));
        }

        // --- Cannabis: slow lazy drift + smoke curls
        float weed = intensity(p, ModEffects.CANNABIS);
        if (weed > 0) {
            turn(p, MathHelper.sin(t * 0.4f) * 0.15f * weed, MathHelper.sin(t * 0.3f) * 0.08f * weed);
            if (r.nextInt(6) == 0) c.world.addParticle(ParticleTypes.SMOKE, p.getX() + r.nextGaussian() * 0.6, p.getEyeY() + 0.3, p.getZ() + r.nextGaussian() * 0.6, 0, 0.02, 0);
        }

        // --- LSD: breathing camera, rainbow sparkles, crystalline chimes
        float lsd = intensity(p, ModEffects.LSD);
        if (lsd > 0) {
            turn(p, MathHelper.sin(t * 0.8f) * 0.12f * lsd, 0);
            for (int i = 0; i < 2; i++) {
                c.world.addParticle(Fx.rainbowDust(t * 0.2f + r.nextFloat(), 1.0f),
                        p.getX() + r.nextGaussian() * 3, p.getY() + r.nextDouble() * 3, p.getZ() + r.nextGaussian() * 3, 0, 0.02, 0);
            }
            if (r.nextInt(90) == 0) c.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 0.5f + r.nextFloat(), 0.7f));
        }

        // --- Shrooms: spores drifting everywhere
        float shroom = intensity(p, ModEffects.SHROOMS);
        if (shroom > 0) {
            for (int i = 0; i < 3; i++) {
                c.world.addParticle(ParticleTypes.SPORE_BLOSSOM_AIR, p.getX() + r.nextGaussian() * 4, p.getY() + r.nextDouble() * 3, p.getZ() + r.nextGaussian() * 4, 0, 0, 0);
            }
            turn(p, MathHelper.sin(t * 0.6f) * 0.1f * shroom, MathHelper.cos(t * 0.5f) * 0.06f * shroom);
        }

        // --- Mescaline: glowing motes
        float mesc = intensity(p, ModEffects.MESCALINE);
        if (mesc > 0 && r.nextInt(3) == 0) {
            c.world.addParticle(ParticleTypes.END_ROD, p.getX() + r.nextGaussian() * 3, p.getY() + r.nextDouble() * 3, p.getZ() + r.nextGaussian() * 3, 0, 0.01, 0);
        }

        // --- Ketamine: slow detached float, ash in the air, time feels far away
        float ket = intensity(p, ModEffects.KETAMINE);
        if (ket > 0) {
            turn(p, MathHelper.sin(t * 0.25f) * 0.35f * ket, MathHelper.sin(t * 0.18f) * 0.2f * ket);
            if (r.nextInt(2) == 0) c.world.addParticle(ParticleTypes.WHITE_ASH, p.getX() + r.nextGaussian() * 3, p.getY() + r.nextDouble() * 3, p.getZ() + r.nextGaussian() * 3, 0, 0, 0);
        }

        // --- Salvia: the world keeps spinning, with sudden lurches
        float salvia = intensity(p, ModEffects.SALVIA);
        if (salvia > 0) {
            turn(p, 1.4f * salvia + (r.nextInt(40) == 0 ? (r.nextFloat() - 0.5f) * 40f * salvia : 0), MathHelper.sin(t * 0.9f) * 0.3f * salvia);
            if (r.nextInt(3) == 0) c.world.addParticle(ParticleTypes.SCULK_SOUL, p.getX() + r.nextGaussian() * 2, p.getY() + r.nextDouble() * 2, p.getZ() + r.nextGaussian() * 2, 0, 0.02, 0);
        }

        // --- Breakthrough: rising hum
        if (p.hasStatusEffect(ModEffects.BREAKTHROUGH) && ACTIVE_TICKS.getOrDefault(ModEffects.BREAKTHROUGH, 0) == 1) {
            c.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.BLOCK_BEACON_POWER_SELECT, 0.5f, 1.0f));
        }

        // --- The House: how close is it?
        if (inHouse(c)) {
            float target = 0f;
            for (HollowEntity h : c.world.getEntitiesByClass(HollowEntity.class, p.getBoundingBox().expand(20), e -> true)) {
                float d = p.distanceTo(h);
                target = Math.max(target, MathHelper.clamp(1f - (d - 2f) / 16f, 0f, 1f));
            }
            dread += (target - dread) * 0.08f;
            if (r.nextInt(8) == 0) c.world.addParticle(ParticleTypes.ASH, p.getX() + r.nextGaussian() * 4, p.getY() + r.nextDouble() * 3, p.getZ() + r.nextGaussian() * 4, 0, 0, 0);
        } else {
            dread = 0f;
        }
    }

    private static void turn(ClientPlayerEntity p, float yaw, float pitch) {
        p.setYaw(p.getYaw() + yaw);
        p.setPitch(MathHelper.clamp(p.getPitch() + pitch, -90f, 90f));
    }
}
