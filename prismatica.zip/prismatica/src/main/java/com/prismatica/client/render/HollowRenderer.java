package com.prismatica.client.render;

import com.prismatica.Prismatica;
import com.prismatica.entity.HollowEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.feature.EyesFeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.util.Identifier;

public class HollowRenderer extends MobEntityRenderer<HollowEntity, HollowModel> {
    private static final Identifier TEXTURE = Prismatica.id("textures/entity/the_hollow.png");

    public HollowRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new HollowModel(ctx.getPart(HollowModel.LAYER)), 0.4f);
        this.addFeature(new Eyes(this));
    }

    @Override
    public Identifier getTexture(HollowEntity entity) {
        return TEXTURE;
    }

    /** Pin-prick pupils and teeth that glow in total darkness. */
    public static class Eyes extends EyesFeatureRenderer<HollowEntity, HollowModel> {
        private static final RenderLayer LAYER = RenderLayer.getEyes(Prismatica.id("textures/entity/the_hollow_eyes.png"));

        public Eyes(FeatureRendererContext<HollowEntity, HollowModel> ctx) {
            super(ctx);
        }

        @Override
        public RenderLayer getEyesTexture() {
            return LAYER;
        }
    }
}
