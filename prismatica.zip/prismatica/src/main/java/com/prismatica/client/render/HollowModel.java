package com.prismatica.client.render;

import com.prismatica.Prismatica;
import com.prismatica.entity.HollowEntity;
import net.minecraft.client.model.*;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

/**
 * The Hollow Host: ~59px (3.7 blocks) tall. Stick-thin legs, a narrow ribbed torso,
 * arms hanging to its knees and a tall, eyeless head split by a vertical mouth.
 */
public class HollowModel extends SinglePartEntityModel<HollowEntity> {
    public static final EntityModelLayer LAYER = new EntityModelLayer(Prismatica.id("the_hollow"), "main");
    private static final float DEG = (float) (Math.PI / 180);

    private final ModelPart root;
    private final ModelPart head, neck, torso, rightArm, leftArm, rightLeg, leftLeg;

    public HollowModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.neck = root.getChild("neck");
        this.torso = root.getChild("torso");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData r = data.getRoot();
        r.addChild("torso", ModelPartBuilder.create().uv(32, 0).cuboid(-4f, -18f, -2f, 8f, 18f, 4f), ModelTransform.pivot(0f, -2f, 0f));
        r.addChild("neck", ModelPartBuilder.create().uv(60, 0).cuboid(-1f, -4f, -1f, 2f, 4f, 2f), ModelTransform.pivot(0f, -20f, 0f));
        r.addChild("head", ModelPartBuilder.create().uv(0, 0).cuboid(-3.5f, -11f, -3.5f, 7f, 11f, 7f), ModelTransform.pivot(0f, -24f, 0f));
        r.addChild("right_arm", ModelPartBuilder.create().uv(0, 20).cuboid(-1f, -1f, -1f, 2f, 30f, 2f), ModelTransform.pivot(-5.5f, -18f, 0f));
        r.addChild("left_arm", ModelPartBuilder.create().uv(10, 20).cuboid(-1f, -1f, -1f, 2f, 30f, 2f), ModelTransform.pivot(5.5f, -18f, 0f));
        r.addChild("right_leg", ModelPartBuilder.create().uv(20, 24).cuboid(-1.5f, 0f, -1.5f, 3f, 26f, 3f), ModelTransform.pivot(-2f, -2f, 0f));
        r.addChild("left_leg", ModelPartBuilder.create().uv(34, 24).cuboid(-1.5f, 0f, -1.5f, 3f, 26f, 3f), ModelTransform.pivot(2f, -2f, 0f));
        return TexturedModelData.of(data, 128, 64);
    }

    @Override
    public ModelPart getPart() {
        return root;
    }

    @Override
    public void setAngles(HollowEntity entity, float limbAngle, float limbDistance, float age, float headYaw, float headPitch) {
        boolean watched = entity.isWatched();
        // Irregular twitch made of two out-of-phase sines
        float twitch = MathHelper.sin(age * 0.9f) * MathHelper.sin(age * 2.3f);

        head.yaw = headYaw * DEG;
        head.pitch = headPitch * DEG;
        neck.pitch = 0f;
        torso.pitch = 0f;

        if (watched) {
            // Frozen mid-step, head cocked hard to one side, arms slightly raised toward you
            head.roll = 0.6f + twitch * 0.04f;
            head.pitch += 0.25f;
            rightArm.pitch = -0.35f;
            leftArm.pitch = -0.25f;
            rightArm.roll = 0.12f;
            leftArm.roll = -0.12f;
            rightLeg.pitch = 0.25f;
            leftLeg.pitch = -0.2f;
        } else {
            float swing = MathHelper.cos(limbAngle * 0.45f) * 1.0f * limbDistance;
            head.roll = twitch * 0.15f;
            rightLeg.pitch = swing;
            leftLeg.pitch = -swing;
            rightArm.pitch = -swing * 0.7f - 0.15f * limbDistance;
            leftArm.pitch = swing * 0.7f - 0.15f * limbDistance;
            rightArm.roll = 0.05f + MathHelper.sin(age * 0.07f) * 0.06f;
            leftArm.roll = -rightArm.roll;
        }
        rightArm.yaw = 0f;
        leftArm.yaw = 0f;
    }
}
