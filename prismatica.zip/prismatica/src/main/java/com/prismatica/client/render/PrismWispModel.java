package com.prismatica.client.render;

import com.prismatica.Prismatica;
import com.prismatica.entity.PrismWispEntity;
import net.minecraft.client.model.*;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

/** A tumbling crystal core with four motes orbiting it. */
public class PrismWispModel extends SinglePartEntityModel<PrismWispEntity> {
    public static final EntityModelLayer LAYER = new EntityModelLayer(Prismatica.id("prism_wisp"), "main");

    private final ModelPart root, core, orbit;

    public PrismWispModel(ModelPart root) {
        this.root = root;
        this.core = root.getChild("core");
        this.orbit = root.getChild("orbit");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData r = data.getRoot();
        r.addChild("core", ModelPartBuilder.create().uv(0, 0).cuboid(-2f, -2f, -2f, 4f, 4f, 4f), ModelTransform.pivot(0f, 19f, 0f));
        r.addChild("orbit", ModelPartBuilder.create()
                        .uv(0, 8).cuboid(3.5f, -0.5f, -0.5f, 1f, 1f, 1f)
                        .uv(0, 8).cuboid(-4.5f, -0.5f, -0.5f, 1f, 1f, 1f)
                        .uv(0, 8).cuboid(-0.5f, -0.5f, 3.5f, 1f, 1f, 1f)
                        .uv(0, 8).cuboid(-0.5f, -0.5f, -4.5f, 1f, 1f, 1f),
                ModelTransform.pivot(0f, 19f, 0f));
        return TexturedModelData.of(data, 16, 16);
    }

    @Override
    public ModelPart getPart() {
        return root;
    }

    @Override
    public void setAngles(PrismWispEntity entity, float limbAngle, float limbDistance, float age, float headYaw, float headPitch) {
        core.yaw = age * 0.08f;
        core.pitch = age * 0.05f;
        core.pivotY = 19f + MathHelper.sin(age * 0.12f) * 1.0f;
        orbit.yaw = -age * 0.2f;
        orbit.roll = MathHelper.sin(age * 0.05f) * 0.4f;
        orbit.pivotY = core.pivotY;
    }
}
