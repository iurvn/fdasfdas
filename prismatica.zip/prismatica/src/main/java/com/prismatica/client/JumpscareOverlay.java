package com.prismatica.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.prismatica.Prismatica;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;

/** Full-screen Hollow face, violent shake, red strobe, three layered screams. */
public final class JumpscareOverlay {
    private JumpscareOverlay() {}

    private static final Identifier FACE = Prismatica.id("textures/gui/jumpscare.png");
    private static final int DURATION = 38;
    private static final Random RANDOM = Random.create();
    private static int ticks;

    public static void trigger() {
        ticks = DURATION;
        MinecraftClient c = MinecraftClient.getInstance();
        c.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ENTITY_ENDERMAN_SCREAM, 0.5f, 1.0f));
        c.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ENTITY_GHAST_SCREAM, 0.6f, 1.0f));
        c.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 0.7f, 1.0f));
    }

    public static boolean active() {
        return ticks > 0;
    }

    public static void tick() {
        if (ticks > 0) ticks--;
    }

    public static void render(DrawContext ctx) {
        if (ticks <= 0) return;
        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();
        float progress = 1f - ticks / (float) DURATION;

        ctx.fill(0, 0, w, h, 0xFF000000);
        int base = (int) (Math.min(w, h) * (1.05f + progress * 0.9f));
        int shake = (int) (14 * (1f - progress * 0.5f));
        int x = (w - base) / 2 + RANDOM.nextInt(shake * 2 + 1) - shake;
        int y = (h - base) / 2 + RANDOM.nextInt(shake * 2 + 1) - shake;

        RenderSystem.enableBlend();
        ctx.drawTexture(FACE, x, y, 0f, 0f, base, base, base, base);
        // Red strobe + scanline flicker
        if ((ticks / 2) % 2 == 0) ctx.fill(0, 0, w, h, 0x55FF0000);
        for (int i = 0; i < 6; i++) {
            int ly = RANDOM.nextInt(Math.max(1, h));
            ctx.fill(0, ly, w, ly + 1 + RANDOM.nextInt(3), 0x66000000);
        }
        // Fade to black at the end
        if (ticks < 10) {
            int alpha = (int) ((1f - ticks / 10f) * 255) & 0xFF;
            ctx.fill(0, 0, w, h, alpha << 24);
        }
        RenderSystem.disableBlend();
    }
}
