package com.prismatica.client;

import com.prismatica.client.render.*;
import com.prismatica.network.JumpscarePayload;
import com.prismatica.registry.ModBlocks;
import com.prismatica.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.FlyingItemEntityRenderer;

public class PrismaticaClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.NEBULA_GLASS, RenderLayer.getTranslucent());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.CANNABIS_CROP, RenderLayer.getCutout());

        EntityModelLayerRegistry.registerModelLayer(HollowModel.LAYER, HollowModel::getTexturedModelData);
        EntityModelLayerRegistry.registerModelLayer(PrismWispModel.LAYER, PrismWispModel::getTexturedModelData);
        EntityRendererRegistry.register(ModEntities.THE_HOLLOW, HollowRenderer::new);
        EntityRendererRegistry.register(ModEntities.PRISM_WISP, PrismWispRenderer::new);
        EntityRendererRegistry.register(ModEntities.VORTEX_ORB, FlyingItemEntityRenderer::new);

        ClientPlayNetworking.registerGlobalReceiver(JumpscarePayload.ID,
                (payload, context) -> context.client().execute(JumpscareOverlay::trigger));

        TripVisuals.init();
        ClientTickEvents.END_CLIENT_TICK.register(client -> JumpscareOverlay.tick());
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> JumpscareOverlay.render(drawContext));
    }
}
