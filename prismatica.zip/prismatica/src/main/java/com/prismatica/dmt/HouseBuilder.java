package com.prismatica.dmt;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.enums.BedPart;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.List;

/**
 * Builds The House inside the_house dimension (a black void with thick black fog).
 *
 *   Layout (top-down, north = up, x: -16..16, z: -12..12)
 *   +-----------+-----------+-----------+
 *   |  BEDROOM  |  LIBRARY  |  DINING   |
 *   +----  ----+----  -----+----  -----+
 *   | >>> spawn      HALLWAY       end |
 *   +----  ----+----  -----+----  -----+
 *   |  KITCHEN  |  PARLOR   |  STORAGE  |
 *   +-----------+-----------+-----------+
 */
public final class HouseBuilder {
    private HouseBuilder() {}

    private static final int FLAGS = Block.NOTIFY_LISTENERS | Block.FORCE_STATE;
    private static final BlockPos MARKER = new BlockPos(0, 60, 0);
    private static final int F = 64; // floor level

    public static final Vec3d PLAYER_SPAWN = new Vec3d(-13.5, 65.1, 0.5);
    public static final float PLAYER_YAW = -90f; // facing east, down the hallway

    public static final List<BlockPos> LURK_POINTS = List.of(
            new BlockPos(13, 65, 0), new BlockPos(-11, 65, -6), new BlockPos(0, 65, -9), new BlockPos(11, 65, -4),
            new BlockPos(-11, 65, 7), new BlockPos(0, 65, 5), new BlockPos(11, 65, 7));

    /** candle position -> candle count */
    private static final List<BlockPos> CANDLES = new ArrayList<>();
    private static final List<BlockState> CANDLE_STATES = new ArrayList<>();

    static {
        candle(-12, 65, -1, Blocks.BLACK_CANDLE, 2);
        candle(-4, 65, -1, Blocks.BLACK_CANDLE, 1);
        candle(4, 65, -1, Blocks.BLACK_CANDLE, 2);
        candle(12, 65, -1, Blocks.BLACK_CANDLE, 1);
        candle(-8, 65, 1, Blocks.BLACK_CANDLE, 1);
        candle(8, 65, 1, Blocks.BLACK_CANDLE, 2);
        candle(-15, 66, -11, Blocks.WHITE_CANDLE, 1);   // bedroom nightstand
        candle(-3, 65, -8, Blocks.CANDLE, 3);          // library
        candle(3, 65, -8, Blocks.CANDLE, 1);
        candle(9, 66, -7, Blocks.RED_CANDLE, 2);       // dining table
        candle(12, 66, -7, Blocks.RED_CANDLE, 1);
        candle(-12, 66, 11, Blocks.RED_CANDLE, 1);     // kitchen counter
        candle(-4, 65, 10, Blocks.WHITE_CANDLE, 2);    // parlor
        candle(14, 65, 4, Blocks.BLACK_CANDLE, 1);     // storage
    }

    private static void candle(int x, int y, int z, Block block, int count) {
        CANDLES.add(new BlockPos(x, y, z));
        CANDLE_STATES.add(block.getDefaultState().with(Properties.CANDLES, count).with(Properties.LIT, true));
    }

    public static void ensureBuilt(ServerWorld w) {
        if (w.getBlockState(MARKER).isOf(Blocks.BEDROCK)) return;
        build(w);
        w.setBlockState(MARKER, Blocks.BEDROCK.getDefaultState(), FLAGS);
    }

    public static void relightCandles(ServerWorld w) {
        for (int i = 0; i < CANDLES.size(); i++) w.setBlockState(CANDLES.get(i), CANDLE_STATES.get(i), FLAGS);
    }

    public static void extinguishNear(ServerWorld w, BlockPos center, double radius) {
        for (BlockPos p : CANDLES) {
            if (p.getSquaredDistance(center) > radius * radius) continue;
            BlockState s = w.getBlockState(p);
            if (s.contains(Properties.LIT)) w.setBlockState(p, s.with(Properties.LIT, false), FLAGS);
        }
    }

    // ------------------------------------------------------------------------------------------

    private static void build(ServerWorld w) {
        Random r = Random.create(1337L);
        BlockState air = Blocks.AIR.getDefaultState();
        BlockState darkOak = Blocks.DARK_OAK_PLANKS.getDefaultState();
        BlockState spruce = Blocks.SPRUCE_PLANKS.getDefaultState();
        BlockState log = Blocks.STRIPPED_DARK_OAK_LOG.getDefaultState();

        // Shell
        fill(w, -17, F - 2, -13, 17, F - 1, 13, Blocks.DEEPSLATE_BRICKS.getDefaultState());
        for (int x = -16; x <= 16; x++) {
            for (int z = -12; z <= 12; z++) {
                float roll = r.nextFloat();
                BlockState floor = roll < 0.06f ? Blocks.CRACKED_DEEPSLATE_TILES.getDefaultState()
                        : roll < 0.16f ? Blocks.DEEPSLATE_TILES.getDefaultState() : darkOak;
                set(w, x, F, z, floor);
                set(w, x, F + 6, z, darkOak);
                set(w, x, F + 7, z, Blocks.BLACKSTONE.getDefaultState());
            }
        }
        fill(w, -15, F + 1, -11, 15, F + 5, 11, air);

        // Outer walls with log pillars
        for (int y = F + 1; y <= F + 5; y++) {
            for (int x = -16; x <= 16; x++) {
                BlockState s = (x % 4 == 0) ? log : darkOak;
                set(w, x, y, -12, s);
                set(w, x, y, 12, s);
            }
            for (int z = -12; z <= 12; z++) {
                BlockState s = (z % 4 == 0) ? log : darkOak;
                set(w, -16, y, z, s);
                set(w, 16, y, z, s);
            }
        }

        // Hallway walls + room partitions
        fill(w, -15, F + 1, -2, 15, F + 5, -2, spruce);
        fill(w, -15, F + 1, 2, 15, F + 5, 2, spruce);
        fill(w, -6, F + 1, -11, -6, F + 5, -3, spruce);
        fill(w, 5, F + 1, -11, 5, F + 5, -3, spruce);
        fill(w, -6, F + 1, 3, -6, F + 5, 11, spruce);
        fill(w, 5, F + 1, 3, 5, F + 5, 11, spruce);

        // 2-wide, 4-tall archways (tall enough for the Hollow)
        int[][] arches = {{-11, -10}, {-1, 0}, {10, 11}};
        for (int[] a : arches) {
            fill(w, a[0], F + 1, -2, a[1], F + 4, -2, air);
            fill(w, a[0], F + 1, 2, a[1], F + 4, 2, air);
        }

        // Windows into the void
        BlockState tinted = Blocks.TINTED_GLASS.getDefaultState();
        for (int[] a : arches) {
            fill(w, a[0], F + 2, -12, a[1], F + 3, -12, tinted);
            fill(w, a[0], F + 2, 12, a[1], F + 3, 12, tinted);
        }
        fill(w, 16, F + 2, -1, 16, F + 3, 1, tinted);
        fill(w, -16, F + 2, 0, -16, F + 3, 0, tinted);

        // Hallway: long red runner, one hanging soul lantern
        fill(w, -14, F + 1, 0, 14, F + 1, 0, Blocks.RED_CARPET.getDefaultState());
        set(w, 0, F + 5, 0, Blocks.SOUL_LANTERN.getDefaultState().with(Properties.HANGING, true));
        set(w, 15, F + 5, -1, Blocks.COBWEB.getDefaultState());
        set(w, -15, F + 5, 1, Blocks.COBWEB.getDefaultState());
        set(w, 15, F + 1, 1, Blocks.SKELETON_SKULL.getDefaultState().with(Properties.ROTATION, 4));

        buildBedroom(w);
        buildLibrary(w);
        buildDining(w);
        buildKitchen(w);
        buildParlor(w);
        buildStorage(w, r);

        relightCandles(w);
    }

    private static void buildBedroom(ServerWorld w) {
        set(w, -13, F + 1, -10, Blocks.GRAY_BED.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.NORTH).with(Properties.BED_PART, BedPart.FOOT));
        set(w, -13, F + 1, -11, Blocks.GRAY_BED.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.NORTH).with(Properties.BED_PART, BedPart.HEAD));
        set(w, -15, F + 1, -11, Blocks.BARREL.getDefaultState());
        set(w, -8, F + 1, -11, Blocks.CHEST.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.SOUTH));
        set(w, -7, F + 1, -11, Blocks.BOOKSHELF.getDefaultState());
        set(w, -7, F + 2, -11, Blocks.BOOKSHELF.getDefaultState());
        fill(w, -12, F + 1, -8, -10, F + 1, -6, Blocks.GRAY_CARPET.getDefaultState());
        set(w, -8, F + 1, -4, Blocks.POTTED_WITHER_ROSE.getDefaultState());
        cobwebs(w, new int[][]{{-15, -11}, {-7, -11}, {-15, -3}});
    }

    private static void buildLibrary(ServerWorld w) {
        fill(w, -5, F + 1, -11, 4, F + 4, -11, Blocks.BOOKSHELF.getDefaultState());
        fill(w, -5, F + 1, -10, -5, F + 3, -5, Blocks.BOOKSHELF.getDefaultState());
        fill(w, 4, F + 1, -10, 4, F + 3, -5, Blocks.BOOKSHELF.getDefaultState());
        set(w, 0, F + 1, -6, Blocks.LECTERN.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.SOUTH));
        set(w, -1, F + 1, -4, Blocks.DARK_OAK_STAIRS.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.SOUTH));
        set(w, 1, F + 1, -4, Blocks.DARK_OAK_STAIRS.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.SOUTH));
        cobwebs(w, new int[][]{{-5, -11}, {4, -11}, {4, -3}});
    }

    private static void buildDining(ServerWorld w) {
        for (int x = 8; x <= 13; x++) {
            set(w, x, F + 1, -7, Blocks.DARK_OAK_FENCE.getDefaultState());
            set(w, x, F + 2, -7, Blocks.DARK_OAK_PRESSURE_PLATE.getDefaultState());
            if (x % 2 == 0) {
                set(w, x, F + 1, -8, Blocks.DARK_OAK_STAIRS.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.NORTH));
                set(w, x, F + 1, -6, Blocks.DARK_OAK_STAIRS.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.SOUTH));
            }
        }
        set(w, 13, F + 2, -7, Blocks.SKELETON_SKULL.getDefaultState().with(Properties.ROTATION, 4));
        set(w, 15, F + 1, -11, Blocks.BARREL.getDefaultState());
        cobwebs(w, new int[][]{{6, -11}, {15, -11}, {15, -3}});
    }

    private static void buildKitchen(ServerWorld w) {
        set(w, -14, F + 1, 11, Blocks.SMOKER.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.NORTH));
        set(w, -13, F + 1, 11, Blocks.FURNACE.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.NORTH));
        set(w, -12, F + 1, 11, Blocks.CRAFTING_TABLE.getDefaultState());
        set(w, -11, F + 1, 11, Blocks.WATER_CAULDRON.getDefaultState().with(Properties.LEVEL_3, 3));
        set(w, -10, F + 1, 11, Blocks.BARREL.getDefaultState());
        set(w, -9, F + 1, 11, Blocks.BARREL.getDefaultState());
        set(w, -15, F + 1, 11, Blocks.CHAIN.getDefaultState());
        set(w, -15, F + 5, 7, Blocks.CHAIN.getDefaultState());
        set(w, -15, F + 4, 7, Blocks.CHAIN.getDefaultState());
        cobwebs(w, new int[][]{{-15, 3}, {-7, 11}, {-15, 11}});
    }

    private static void buildParlor(ServerWorld w) {
        BlockState bricks = Blocks.DEEPSLATE_BRICKS.getDefaultState();
        fill(w, -2, F + 1, 11, 2, F + 5, 11, bricks);
        set(w, 0, F + 1, 11, Blocks.SOUL_CAMPFIRE.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.NORTH));
        set(w, 0, F + 2, 11, Blocks.AIR.getDefaultState());
        set(w, -2, F + 1, 7, Blocks.DARK_OAK_STAIRS.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.NORTH));
        set(w, 2, F + 1, 7, Blocks.DARK_OAK_STAIRS.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.NORTH));
        fill(w, -1, F + 1, 8, 1, F + 1, 9, Blocks.RED_CARPET.getDefaultState());
        fill(w, -5, F + 1, 4, -5, F + 3, 4, Blocks.DARK_OAK_LOG.getDefaultState());
        set(w, -5, F + 4, 4, Blocks.SKELETON_SKULL.getDefaultState().with(Properties.ROTATION, 4));
        cobwebs(w, new int[][]{{-5, 11}, {4, 11}});
    }

    private static void buildStorage(ServerWorld w, Random r) {
        int[][] barrels = {{15, 11}, {14, 11}, {15, 10}, {15, 3}, {6, 11}, {7, 11}};
        for (int[] b : barrels) set(w, b[0], F + 1, b[1], Blocks.BARREL.getDefaultState());
        set(w, 14, F + 2, 11, Blocks.BARREL.getDefaultState());
        set(w, 6, F + 1, 10, Blocks.CHEST.getDefaultState().with(Properties.HORIZONTAL_FACING, Direction.EAST));
        set(w, 9, F + 1, 10, Blocks.BONE_BLOCK.getDefaultState());
        set(w, 13, F + 1, 10, Blocks.COBWEB.getDefaultState());
        // A drag trail that stops at the wall.
        int[][] trail = {{7, 4}, {8, 5}, {8, 6}, {9, 7}, {10, 8}, {11, 9}, {12, 9}, {12, 10}};
        for (int[] t : trail) set(w, t[0], F + 1, t[1], Blocks.REDSTONE_WIRE.getDefaultState());
        cobwebs(w, new int[][]{{6, 3}, {15, 11}, {6, 11}});
    }

    private static void cobwebs(ServerWorld w, int[][] xz) {
        for (int[] p : xz) set(w, p[0], F + 5, p[1], Blocks.COBWEB.getDefaultState());
    }

    private static void set(ServerWorld w, int x, int y, int z, BlockState s) {
        w.setBlockState(new BlockPos(x, y, z), s, FLAGS);
    }

    private static void fill(ServerWorld w, int x1, int y1, int z1, int x2, int y2, int z2, BlockState s) {
        for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++)
            for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++)
                for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++)
                    set(w, x, y, z, s);
    }
}
