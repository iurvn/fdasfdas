package com.prismatica.dmt;

import com.prismatica.registry.ModDimensions;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.world.World;

/** You can't dig or build your way out of the house (creative mode excepted, for building/debugging). */
public final class HouseProtection {
    private HouseProtection() {}

    private static boolean locked(World world, PlayerEntity player) {
        return world.getRegistryKey().equals(ModDimensions.THE_HOUSE) && !player.isCreative();
    }

    public static void init() {
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> !locked(world, player));
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) ->
                locked(world, player) ? ActionResult.FAIL : ActionResult.PASS);
        UseBlockCallback.EVENT.register((player, world, hand, hit) ->
                locked(world, player) ? ActionResult.FAIL : ActionResult.PASS);
    }
}
