package com.prismatica.dmt;

import com.prismatica.Prismatica;
import com.prismatica.entity.HollowEntity;
import com.prismatica.fx.Scheduler;
import com.prismatica.network.JumpscarePayload;
import com.prismatica.registry.ModDimensions;
import com.prismatica.registry.ModEffects;
import com.prismatica.registry.ModEntities;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.*;

/**
 * Drives a DMT trip:
 *   ONSET   (3.5s)  breakthrough shader, then you're pulled into The House
 *   HOUSE   (~2min) candles, noises, the Hollow wakes up after ~12s and hunts you
 *                   at 70s the candles near you go out
 *   FINALE          if you survive the timer, it is simply standing in front of you
 *   SCARE   (2s)    jumpscare, then you wake up where you were
 */
public final class DmtTripManager {
    private DmtTripManager() {}

    private static final int ONSET_TICKS = 70;
    private static final int HOLLOW_SPAWN = 240;
    private static final int LIGHTS_OUT = 1400;
    private static final int FINALE_AT = 2400;
    private static final int FINALE_TICKS = 30;
    private static final int SCARE_TICKS = 40;

    private enum Phase { ONSET, HOUSE, FINALE, SCARE }

    private static final class Trip {
        final RegistryKey<World> returnDim;
        final Vec3d returnPos;
        final float yaw, pitch;
        Phase phase = Phase.ONSET;
        int ticks;
        UUID hollow;

        Trip(RegistryKey<World> dim, Vec3d pos, float yaw, float pitch) {
            this.returnDim = dim;
            this.returnPos = pos;
            this.yaw = yaw;
            this.pitch = pitch;
        }
    }

    private static final Map<UUID, Trip> TRIPS = new HashMap<>();

    private static final SoundEvent[] HOUSE_SOUNDS = {
            SoundEvents.BLOCK_WOOD_STEP, SoundEvents.BLOCK_WOODEN_DOOR_CLOSE, SoundEvents.ENTITY_WARDEN_HEARTBEAT,
            SoundEvents.BLOCK_CHEST_OPEN, SoundEvents.ENTITY_GHAST_AMBIENT, SoundEvents.ENTITY_ENDERMAN_AMBIENT,
            SoundEvents.BLOCK_BELL_RESONATE, SoundEvents.ENTITY_WARDEN_NEARBY_CLOSE, SoundEvents.BLOCK_WOOD_STEP
    };

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(DmtTripManager::tick);
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            Trip t = TRIPS.remove(handler.getPlayer().getUuid());
            if (t != null) removeHollow(server, t);
        });
        // Anyone who logs in while stuck in the house (crash, quit mid-trip) gets sent home.
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity p = handler.getPlayer();
            Scheduler.schedule(5, () -> {
                if (p.isRemoved() || TRIPS.containsKey(p.getUuid())) return;
                if (p.getWorld().getRegistryKey().equals(ModDimensions.THE_HOUSE)) sendToSpawn(server, p);
            });
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> TRIPS.clear());
    }

    public static boolean isTripping(ServerPlayerEntity p) {
        return TRIPS.containsKey(p.getUuid());
    }

    public static void startTrip(ServerPlayerEntity p) {
        if (TRIPS.containsKey(p.getUuid())) return;
        TRIPS.put(p.getUuid(), new Trip(p.getWorld().getRegistryKey(), p.getPos(), p.getYaw(), p.getPitch()));
        p.addStatusEffect(new StatusEffectInstance(ModEffects.BREAKTHROUGH, ONSET_TICKS + 10, 0, false, false, false));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, ONSET_TICKS, 5, false, false, false));
        ServerWorld w = p.getServerWorld();
        w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.PLAYERS, 1f, 0.5f);
        w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_RESONATE, SoundCategory.PLAYERS, 1f, 0.5f);
        w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_CONDUIT_ACTIVATE, SoundCategory.PLAYERS, 1f, 0.6f);
    }

    /** Called by the Hollow when it reaches its player. */
    public static void onCaught(ServerPlayerEntity p, HollowEntity hollow) {
        Trip t = TRIPS.get(p.getUuid());
        if (t == null) {
            // Spawn-egg Hollow outside a trip: still scares you, then vanishes.
            ServerPlayNetworking.send(p, new JumpscarePayload(0));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 100, 0));
            hollow.discard();
            return;
        }
        if (t.phase == Phase.HOUSE || t.phase == Phase.FINALE) beginScare(p, t);
    }

    private static void tick(MinecraftServer server) {
        if (TRIPS.isEmpty()) return;
        Iterator<Map.Entry<UUID, Trip>> it = TRIPS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Trip> e = it.next();
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(e.getKey());
            Trip t = e.getValue();
            boolean keep;
            try {
                keep = p != null && p.isAlive() && tickTrip(server, p, t);
            } catch (Exception ex) {
                Prismatica.LOGGER.error("DMT trip failed", ex);
                keep = false;
                if (p != null) wake(server, p, t);
            }
            if (!keep) {
                removeHollow(server, t);
                it.remove();
            }
        }
    }

    private static boolean tickTrip(MinecraftServer server, ServerPlayerEntity p, Trip t) {
        t.ticks++;
        switch (t.phase) {
            case ONSET -> {
                if (t.ticks < ONSET_TICKS) return true;
                ServerWorld house = server.getWorld(ModDimensions.THE_HOUSE);
                if (house == null) {
                    p.sendMessage(Text.literal("The door would not open. (prismatica:the_house dimension is missing)").formatted(Formatting.RED), false);
                    return false;
                }
                HouseBuilder.ensureBuilt(house);
                HouseBuilder.relightCandles(house);
                p.stopRiding();
                Vec3d s = HouseBuilder.PLAYER_SPAWN;
                p.teleport(house, s.x, s.y, s.z, HouseBuilder.PLAYER_YAW, 0f);
                p.fallDistance = 0;
                p.removeStatusEffect(StatusEffects.SLOWNESS);
                t.phase = Phase.HOUSE;
                t.ticks = 0;
                p.sendMessage(Text.literal("You are not alone in here.").formatted(Formatting.DARK_GRAY, Formatting.ITALIC), true);
                house.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_WOODEN_DOOR_CLOSE, SoundCategory.HOSTILE, 1f, 0.5f);
            }
            case HOUSE -> {
                ServerWorld w = p.getServerWorld();
                if (!w.getRegistryKey().equals(ModDimensions.THE_HOUSE)) return false;
                if (t.ticks == HOLLOW_SPAWN) spawnHollow(w, p, t);
                if (t.ticks > HOLLOW_SPAWN && t.ticks % 100 == 0 && findHollow(server, t) == null) spawnHollow(w, p, t);
                if (t.ticks % 180 == 0) ambientSound(w, p);
                if (t.ticks == 600) p.sendMessage(Text.literal("Don't look away.").formatted(Formatting.DARK_GRAY, Formatting.ITALIC), true);
                if (t.ticks == LIGHTS_OUT) {
                    HouseBuilder.extinguishNear(w, p.getBlockPos(), 14);
                    w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_CANDLE_EXTINGUISH, SoundCategory.HOSTILE, 2f, 0.6f);
                    p.sendMessage(Text.literal("The candles go out.").formatted(Formatting.DARK_GRAY, Formatting.ITALIC), true);
                }
                if (t.ticks >= FINALE_AT) startFinale(server, w, p, t);
            }
            case FINALE -> {
                if (t.ticks >= FINALE_TICKS) beginScare(p, t);
            }
            case SCARE -> {
                if (t.ticks >= SCARE_TICKS) {
                    wake(server, p, t);
                    return false;
                }
            }
        }
        return true;
    }

    private static void spawnHollow(ServerWorld w, ServerPlayerEntity p, Trip t) {
        removeHollow(w.getServer(), t);
        BlockPos best = HouseBuilder.LURK_POINTS.get(0);
        double bestDist = -1;
        for (BlockPos bp : HouseBuilder.LURK_POINTS) {
            double d = Vec3d.ofBottomCenter(bp).squaredDistanceTo(p.getPos());
            if (d > bestDist) {
                bestDist = d;
                best = bp;
            }
        }
        HollowEntity h = ModEntities.THE_HOLLOW.create(w);
        if (h == null) return;
        h.refreshPositionAndAngles(best.getX() + 0.5, best.getY(), best.getZ() + 0.5, 0, 0);
        h.setTargetPlayer(p.getUuid());
        h.setLurkTicks(100);
        h.setPersistent();
        w.spawnEntity(h);
        t.hollow = h.getUuid();
        w.playSound(null, best, SoundEvents.ENTITY_WARDEN_EMERGE, SoundCategory.HOSTILE, 0.6f, 0.5f);
    }

    private static void startFinale(MinecraftServer server, ServerWorld w, ServerPlayerEntity p, Trip t) {
        t.phase = Phase.FINALE;
        t.ticks = 0;
        HouseBuilder.extinguishNear(w, p.getBlockPos(), 64);
        HollowEntity h = findHollow(server, t);
        if (h == null) {
            spawnHollow(w, p, t);
            h = findHollow(server, t);
        }
        if (h == null) return;
        Vec3d look = p.getRotationVec(1f);
        Vec3d flat = new Vec3d(look.x, 0, look.z);
        flat = flat.lengthSquared() < 1e-4 ? new Vec3d(1, 0, 0) : flat.normalize();
        Vec3d pos = p.getPos().add(flat.multiply(2.2));
        h.setLurkTicks(FINALE_TICKS + 5);
        h.refreshPositionAndAngles(pos.x, p.getY(), pos.z, 0, 0);
        h.faceTowards(p);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_WARDEN_HEARTBEAT, SoundCategory.HOSTILE, 2f, 0.5f);
    }

    private static void beginScare(ServerPlayerEntity p, Trip t) {
        if (t.phase == Phase.SCARE) return;
        t.phase = Phase.SCARE;
        t.ticks = 0;
        ServerPlayNetworking.send(p, new JumpscarePayload(0));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, SCARE_TICKS, 10, false, false, false));
        removeHollow(p.getServer(), t);
    }

    private static void wake(MinecraftServer server, ServerPlayerEntity p, Trip t) {
        ServerWorld back = server.getWorld(t.returnDim);
        if (back == null) back = server.getOverworld();
        p.teleport(back, t.returnPos.x, t.returnPos.y, t.returnPos.z, t.yaw, t.pitch);
        p.fallDistance = 0;
        p.removeStatusEffect(ModEffects.BREAKTHROUGH);
        p.removeStatusEffect(StatusEffects.SLOWNESS);
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 160, 0, false, false, false));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 80, 0, false, false, false));
        p.sendMessage(Text.literal("You wake up gasping. The house remembers you.").formatted(Formatting.DARK_GRAY, Formatting.ITALIC), true);
    }

    private static void ambientSound(ServerWorld w, ServerPlayerEntity p) {
        SoundEvent s = HOUSE_SOUNDS[w.random.nextInt(HOUSE_SOUNDS.length)];
        Vec3d look = p.getRotationVec(1f);
        double side = w.random.nextBoolean() ? 1 : -1;
        Vec3d at = p.getPos().add(-look.x * 4 + look.z * 3 * side, 1, -look.z * 4 - look.x * 3 * side);
        float pitch = s == SoundEvents.ENTITY_GHAST_AMBIENT || s == SoundEvents.ENTITY_ENDERMAN_AMBIENT ? 0.4f : 0.7f + w.random.nextFloat() * 0.3f;
        w.playSound(null, at.x, at.y, at.z, s, SoundCategory.HOSTILE, 0.9f, pitch);
    }

    private static HollowEntity findHollow(MinecraftServer server, Trip t) {
        if (t.hollow == null) return null;
        ServerWorld house = server.getWorld(ModDimensions.THE_HOUSE);
        if (house == null) return null;
        Entity e = house.getEntity(t.hollow);
        return e instanceof HollowEntity h && h.isAlive() ? h : null;
    }

    private static void removeHollow(MinecraftServer server, Trip t) {
        if (server == null) return;
        HollowEntity h = findHollow(server, t);
        if (h != null) h.discard();
        t.hollow = null;
    }

    private static void sendToSpawn(MinecraftServer server, ServerPlayerEntity p) {
        ServerWorld ow = server.getOverworld();
        BlockPos sp = ow.getSpawnPos();
        int y = ow.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, sp.getX(), sp.getZ());
        p.teleport(ow, sp.getX() + 0.5, y, sp.getZ() + 0.5, 0f, 0f);
        p.sendMessage(Text.literal("You slip out of the house.").formatted(Formatting.DARK_GRAY, Formatting.ITALIC), true);
    }
}
