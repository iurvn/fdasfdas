package com.prismatica.effect;

import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;

/** Marker effect. All the visuals happen client-side in TripVisuals. */
public class TripEffect extends StatusEffect {
    public TripEffect(int color) {
        super(StatusEffectCategory.NEUTRAL, color);
    }
}
