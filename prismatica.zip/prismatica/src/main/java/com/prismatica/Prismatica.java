package com.prismatica;

import com.prismatica.dmt.DmtTripManager;
import com.prismatica.dmt.HouseProtection;
import com.prismatica.fx.Scheduler;
import com.prismatica.handler.ArmorAuraHandler;
import com.prismatica.network.JumpscarePayload;
import com.prismatica.registry.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Prismatica implements ModInitializer {
    public static final String MOD_ID = "prismatica";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModEffects.init();
        ModBlocks.init();
        ModArmorMaterials.init();
        ModEntities.init();
        ModItems.init();
        ModItemGroups.init();
        ModWorldGen.init();

        PayloadTypeRegistry.playS2C().register(JumpscarePayload.ID, JumpscarePayload.CODEC);

        Scheduler.init();
        ArmorAuraHandler.init();
        DmtTripManager.init();
        HouseProtection.init();

        LOGGER.info("Prismatica loaded. The house is waiting.");
    }
}
