package com.prismatica.handler;

import com.prismatica.fx.Fx;
import com.prismatica.registry.ModItems;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

/** Full Prismite armor: orbiting rainbow motes, a sparkle trail, night vision and a speed boost. */
public final class ArmorAuraHandler {
    private ArmorAuraHandler() {}

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int ticks = server.getTicks();
            if (ticks % 2 != 0) return;
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (!fullSet(p) || p.isSpectator()) continue;
                ServerWorld w = p.getServerWorld();
                for (int i = 0; i < 3; i++) {
                    double a = ticks * 0.12 + i * (Math.PI * 2 / 3);
                    double y = p.getY() + 1.0 + Math.sin(ticks * 0.05 + i) * 0.35;
                    w.spawnParticles(Fx.rainbowDust(ticks * 0.005f + i / 3f, 0.8f),
                            p.getX() + Math.cos(a) * 0.85, y, p.getZ() + Math.sin(a) * 0.85, 1, 0, 0, 0, 0);
                }
                double mdx = p.getX() - p.prevX, mdz = p.getZ() - p.prevZ;
                if (mdx * mdx + mdz * mdz > 0.003 && p.isOnGround()) {
                    w.spawnParticles(Fx.rainbowDust(ticks * 0.01f, 1.0f), p.getX(), p.getY() + 0.05, p.getZ(), 2, 0.15, 0, 0.15, 0);
                }
                if (ticks % 40 == 0) {
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 300, 0, true, false, true));
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 60, 0, true, false, true));
                }
            }
        });
    }

    private static boolean fullSet(ServerPlayerEntity p) {
        return is(p, EquipmentSlot.HEAD, ModItems.PRISMITE_HELMET)
                && is(p, EquipmentSlot.CHEST, ModItems.PRISMITE_CHESTPLATE)
                && is(p, EquipmentSlot.LEGS, ModItems.PRISMITE_LEGGINGS)
                && is(p, EquipmentSlot.FEET, ModItems.PRISMITE_BOOTS);
    }

    private static boolean is(ServerPlayerEntity p, EquipmentSlot slot, Item item) {
        return p.getEquippedStack(slot).isOf(item);
    }
}
