package com.prismatica.block;

import com.prismatica.fx.Fx;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Pads you walk over: BOUNCE launches you skyward, RUNE gives a burst of speed. */
public class PadBlock extends FxBlock {
    private final boolean bounce;

    public PadBlock(Settings settings, boolean bounce) {
        super(settings, bounce ? BlockFx.BOUNCE : BlockFx.RUNE);
        this.bounce = bounce;
    }

    @Override
    public void onSteppedOn(World world, BlockPos pos, BlockState state, Entity entity) {
        if (entity.isSneaking()) {
            super.onSteppedOn(world, pos, state, entity);
            return;
        }
        if (bounce) {
            Vec3d v = entity.getVelocity();
            if (v.y < 0.5) {
                entity.setVelocity(v.x * 1.6, 1.35, v.z * 1.6);
                entity.velocityModified = true;
                entity.fallDistance = 0;
                if (world.isClient) {
                    for (int i = 0; i < 24; i++) {
                        double a = i * Math.PI * 2 / 24;
                        world.addParticle(Fx.rainbowDust(i / 24f, 1.2f), pos.getX() + 0.5 + Math.cos(a) * 0.7, pos.getY() + 1.05,
                                pos.getZ() + 0.5 + Math.sin(a) * 0.7, 0, 0, 0);
                    }
                    world.addParticle(ParticleTypes.CLOUD, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, 0, 0.1, 0);
                } else {
                    world.playSound(null, pos, SoundEvents.BLOCK_SLIME_BLOCK_FALL, SoundCategory.BLOCKS, 1f, 1.6f);
                }
            }
        } else if (!world.isClient && entity instanceof LivingEntity living) {
            living.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 60, 2, true, false, true));
            if (world.getTime() % 10 == 0) {
                world.playSound(null, pos, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.BLOCKS, 0.4f, 1.8f);
            }
        }
        super.onSteppedOn(world, pos, state, entity);
    }

    @Override
    public void onLandedUpon(World world, BlockState state, BlockPos pos, Entity entity, float fallDistance) {
        if (bounce && !entity.isSneaking()) {
            entity.handleFallDamage(fallDistance, 0.0f, world.getDamageSources().fall());
        } else {
            super.onLandedUpon(world, state, pos, entity, fallDistance);
        }
    }
}
