package com.prismatica.block;

import net.minecraft.block.BlockState;
import net.minecraft.block.ExperienceDroppingBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.intprovider.IntProvider;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/** Ore that drops XP and sparkles. */
public class FxOreBlock extends ExperienceDroppingBlock {
    private final BlockFx fx;

    public FxOreBlock(IntProvider xp, Settings settings, BlockFx fx) {
        super(xp, settings);
        this.fx = fx;
    }

    @Override
    public void randomDisplayTick(BlockState state, World world, BlockPos pos, Random random) {
        fx.display(world, pos, random);
    }
}
