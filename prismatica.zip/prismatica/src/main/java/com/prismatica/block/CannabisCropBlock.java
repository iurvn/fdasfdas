package com.prismatica.block;

import com.prismatica.registry.ModItems;
import net.minecraft.block.CropBlock;
import net.minecraft.item.ItemConvertible;

public class CannabisCropBlock extends CropBlock {
    public CannabisCropBlock(Settings settings) {
        super(settings);
    }

    @Override
    protected ItemConvertible getSeedsItem() {
        return ModItems.CANNABIS_SEEDS;
    }
}
