package com.prismatica.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/** A full block that constantly throws off ambient particles. */
public class FxBlock extends Block {
    private final BlockFx fx;

    public FxBlock(Settings settings, BlockFx fx) {
        super(settings);
        this.fx = fx;
    }

    @Override
    public void randomDisplayTick(BlockState state, World world, BlockPos pos, Random random) {
        fx.display(world, pos, random);
    }
}
