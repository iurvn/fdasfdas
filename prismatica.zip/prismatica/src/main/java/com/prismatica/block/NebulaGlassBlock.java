package com.prismatica.block;

import net.minecraft.block.BlockState;
import net.minecraft.block.TransparentBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/** Translucent starry glass. */
public class NebulaGlassBlock extends TransparentBlock {
    public NebulaGlassBlock(Settings settings) {
        super(settings);
    }

    @Override
    public void randomDisplayTick(BlockState state, World world, BlockPos pos, Random random) {
        BlockFx.NEBULA.display(world, pos, random);
    }
}
