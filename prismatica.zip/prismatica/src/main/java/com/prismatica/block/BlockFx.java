package com.prismatica.block;

import com.prismatica.fx.Fx;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/** Client-side ambient particle styles shared by all glowing Prismatica blocks. */
public enum BlockFx {
    PRISMITE_ORE, SUNSTONE_ORE, VOID_ORE,
    PRISMITE, SUNSTONE, VOID, AURORA, NEBULA, STARFIELD, BRAZIER, BOUNCE, RUNE, NONE;

    public void display(World world, BlockPos pos, Random r) {
        double x = pos.getX() + 0.5, y = pos.getY() + 0.5, z = pos.getZ() + 0.5;
        float time = world.getTime() * 0.01f;
        switch (this) {
            case PRISMITE_ORE -> {
                if (r.nextInt(3) == 0) world.addParticle(Fx.rainbowDust(time + r.nextFloat(), 0.6f),
                        x + (r.nextDouble() - 0.5) * 1.1, y + (r.nextDouble() - 0.5) * 1.1, z + (r.nextDouble() - 0.5) * 1.1, 0, 0, 0);
            }
            case SUNSTONE_ORE -> {
                if (r.nextInt(3) == 0) world.addParticle(ParticleTypes.SMALL_FLAME,
                        x + (r.nextDouble() - 0.5) * 1.1, y + (r.nextDouble() - 0.5) * 1.1, z + (r.nextDouble() - 0.5) * 1.1, 0, 0.01, 0);
            }
            case VOID_ORE -> {
                if (r.nextInt(2) == 0) world.addParticle(ParticleTypes.REVERSE_PORTAL,
                        x + (r.nextDouble() - 0.5) * 1.2, y + (r.nextDouble() - 0.5) * 1.2, z + (r.nextDouble() - 0.5) * 1.2, 0, 0, 0);
            }
            case PRISMITE -> {
                for (int i = 0; i < 3; i++) {
                    world.addParticle(Fx.rainbowDust(time + i / 3f, 0.9f),
                            x + (r.nextDouble() - 0.5) * 1.3, y + (r.nextDouble() - 0.5) * 1.3, z + (r.nextDouble() - 0.5) * 1.3, 0, 0, 0);
                }
                if (r.nextInt(4) == 0) world.addParticle(ParticleTypes.END_ROD, x, y + 0.6, z, (r.nextDouble() - 0.5) * 0.05, 0.03, (r.nextDouble() - 0.5) * 0.05);
            }
            case SUNSTONE -> {
                for (int i = 0; i < 2; i++) {
                    world.addParticle(Fx.fade(0xFFE082, 0xFF3D00, 1.2f),
                            x + (r.nextDouble() - 0.5) * 1.2, y + 0.55, z + (r.nextDouble() - 0.5) * 1.2, 0, 0.05, 0);
                }
                if (r.nextInt(5) == 0) world.addParticle(ParticleTypes.LAVA, x, y + 0.5, z, 0, 0, 0);
            }
            case VOID -> {
                for (int i = 0; i < 4; i++) {
                    double a = r.nextDouble() * Math.PI * 2;
                    world.addParticle(ParticleTypes.PORTAL, x + Math.cos(a) * 1.4, y + (r.nextDouble() - 0.5), z + Math.sin(a) * 1.4,
                            -Math.cos(a) * 0.9, 0, -Math.sin(a) * 0.9);
                }
            }
            case AURORA -> {
                // Twisting ribbon of color-shifting dust rising out of the lamp
                for (int i = 0; i < 6; i++) {
                    double h = i * 0.25;
                    double a = world.getTime() * 0.15 + h * 3.0;
                    int from = i % 2 == 0 ? 0x00E676 : 0x40C4FF;
                    int to = i % 2 == 0 ? 0xD500F9 : 0x1DE9B6;
                    world.addParticle(Fx.fade(from, to, 1.1f), x + Math.cos(a) * 0.45, y + 0.6 + h, z + Math.sin(a) * 0.45, 0, 0.02, 0);
                }
                if (r.nextInt(3) == 0) world.addParticle(ParticleTypes.GLOW, x, y + 0.7, z, 0, 0.02, 0);
            }
            case NEBULA -> {
                if (r.nextInt(2) == 0) world.addParticle(Fx.dust(r.nextBoolean() ? 0xB388FF : 0xFF80AB, 0.5f),
                        x + (r.nextDouble() - 0.5) * 1.05, y + (r.nextDouble() - 0.5) * 1.05, z + (r.nextDouble() - 0.5) * 1.05, 0, 0, 0);
                if (r.nextInt(6) == 0) world.addParticle(ParticleTypes.ENCHANT, x, y + 0.8, z, (r.nextDouble() - 0.5), 0.2, (r.nextDouble() - 0.5));
            }
            case STARFIELD -> {
                if (r.nextInt(2) == 0) world.addParticle(ParticleTypes.END_ROD,
                        x + (r.nextDouble() - 0.5) * 1.05, y + 0.52, z + (r.nextDouble() - 0.5) * 1.05, 0, 0.005, 0);
                if (r.nextInt(8) == 0) world.addParticle(ParticleTypes.FIREWORK, x, y + 0.6, z, (r.nextDouble() - 0.5) * 0.1, 0.1, (r.nextDouble() - 0.5) * 0.1);
            }
            case BRAZIER -> {
                // Four-armed soul-fire vortex
                double t = world.getTime() * 0.25;
                for (int i = 0; i < 4; i++) {
                    double a = t + i * Math.PI / 2;
                    world.addParticle(ParticleTypes.SOUL_FIRE_FLAME, x + Math.cos(a) * 0.35, y + 0.55, z + Math.sin(a) * 0.35,
                            -Math.sin(a) * 0.03, 0.06, Math.cos(a) * 0.03);
                }
                if (r.nextInt(3) == 0) world.addParticle(ParticleTypes.SOUL, x, y + 0.9, z, 0, 0.04, 0);
            }
            case BOUNCE -> {
                if (r.nextInt(2) == 0) world.addParticle(Fx.dust(0x76FF03, 0.8f), x + (r.nextDouble() - 0.5), y + 0.1, z + (r.nextDouble() - 0.5), 0, 0.1, 0);
            }
            case RUNE -> {
                double a = world.getTime() * 0.3;
                world.addParticle(Fx.dust(0x18FFFF, 0.7f), x + Math.cos(a) * 0.4, y + 0.1, z + Math.sin(a) * 0.4, 0, 0, 0);
                world.addParticle(Fx.dust(0x18FFFF, 0.7f), x - Math.cos(a) * 0.4, y + 0.1, z - Math.sin(a) * 0.4, 0, 0, 0);
            }
            case NONE -> {}
        }
    }
}
