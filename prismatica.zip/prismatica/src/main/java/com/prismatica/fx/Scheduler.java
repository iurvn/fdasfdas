package com.prismatica.fx;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Tiny server-thread task scheduler used for multi-tick spell animations (meteors, novas...). */
public final class Scheduler {
    private static final class Task {
        int ticks;
        final Runnable run;
        Task(int ticks, Runnable run) { this.ticks = ticks; this.run = run; }
    }

    private static final List<Task> TASKS = new ArrayList<>();
    private static final List<Task> PENDING = new ArrayList<>();

    private Scheduler() {}

    public static void schedule(int delayTicks, Runnable run) {
        PENDING.add(new Task(Math.max(0, delayTicks), run));
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> tick());
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            TASKS.clear();
            PENDING.clear();
        });
    }

    private static void tick() {
        TASKS.addAll(PENDING);
        PENDING.clear();
        List<Runnable> due = new ArrayList<>();
        Iterator<Task> it = TASKS.iterator();
        while (it.hasNext()) {
            Task t = it.next();
            if (--t.ticks <= 0) {
                due.add(t.run);
                it.remove();
            }
        }
        for (Runnable r : due) {
            try {
                r.run();
            } catch (Exception e) {
                com.prismatica.Prismatica.LOGGER.error("Scheduled task failed", e);
            }
        }
    }
}
