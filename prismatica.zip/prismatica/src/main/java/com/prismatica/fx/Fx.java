package com.prismatica.fx;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.DustColorTransitionParticleEffect;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3f;

import java.util.List;

/** Shared particle helpers used by weapons, spells and blocks. */
public final class Fx {
    private Fx() {}

    public static Vector3f rainbow(float hue) {
        float h = ((hue % 1f) + 1f) % 1f;
        return rgb(MathHelper.hsvToRgb(h, 0.85f, 1f));
    }

    public static Vector3f rgb(int color) {
        return new Vector3f(((color >> 16) & 255) / 255f, ((color >> 8) & 255) / 255f, (color & 255) / 255f);
    }

    public static DustParticleEffect dust(int color, float scale) {
        return new DustParticleEffect(rgb(color), scale);
    }

    public static DustParticleEffect rainbowDust(float hue, float scale) {
        return new DustParticleEffect(rainbow(hue), scale);
    }

    public static DustColorTransitionParticleEffect fade(int from, int to, float scale) {
        return new DustColorTransitionParticleEffect(rgb(from), rgb(to), scale);
    }

    public static void ring(ServerWorld w, Vec3d c, double radius, int points, ParticleEffect p, double vy) {
        for (int i = 0; i < points; i++) {
            double a = (Math.PI * 2 * i) / points;
            w.spawnParticles(p, c.x + Math.cos(a) * radius, c.y, c.z + Math.sin(a) * radius, 0, 0, vy, 0, 1);
        }
    }

    public static void rainbowRing(ServerWorld w, Vec3d c, double radius, int points, float hueOffset, float scale) {
        for (int i = 0; i < points; i++) {
            double a = (Math.PI * 2 * i) / points;
            w.spawnParticles(rainbowDust(hueOffset + (float) i / points, scale),
                    c.x + Math.cos(a) * radius, c.y, c.z + Math.sin(a) * radius, 1, 0, 0, 0, 0);
        }
    }

    public static void line(ServerWorld w, Vec3d a, Vec3d b, double step, ParticleEffect p) {
        Vec3d d = b.subtract(a);
        double len = d.length();
        if (len < 1e-4) return;
        Vec3d n = d.multiply(1.0 / len);
        for (double t = 0; t <= len; t += step) {
            w.spawnParticles(p, a.x + n.x * t, a.y + n.y * t, a.z + n.z * t, 1, 0, 0, 0, 0);
        }
    }

    public static void spiral(ServerWorld w, Vec3d base, double radius, double height, int points, int arms, ParticleEffect p) {
        for (int arm = 0; arm < arms; arm++) {
            for (int i = 0; i < points; i++) {
                double t = (double) i / points;
                double a = t * Math.PI * 6 + arm * (Math.PI * 2 / arms);
                double r = radius * (1 - t * 0.5);
                w.spawnParticles(p, base.x + Math.cos(a) * r, base.y + t * height, base.z + Math.sin(a) * r, 1, 0, 0, 0, 0);
            }
        }
    }

    /** Living entities around a point, excluding the caster and spectators. */
    public static List<LivingEntity> around(ServerWorld w, Vec3d c, double r, LivingEntity exclude) {
        return w.getEntitiesByClass(LivingEntity.class, Box.of(c, r * 2, r * 2, r * 2),
                e -> e != exclude && e.isAlive() && e.squaredDistanceTo(c) <= r * r
                        && !(e instanceof PlayerEntity p && (p.isSpectator() || p.isCreative())));
    }
}
