#version 150
uniform sampler2D DiffuseSampler;

in vec2 texCoord;
in vec2 oneTexel;
uniform vec2 InSize;
uniform float Clock;
uniform float Intensity;
out vec4 fragColor;

vec3 rgb2hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}
vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}
float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
float noise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p);
    float a = hash(i); float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0)); float d = hash(i + vec2(1.0, 1.0));
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}
vec3 tex(vec2 uv) { return texture(DiffuseSampler, clamp(uv, vec2(0.001), vec2(0.999))).rgb; }
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

void main() {
    float I = clamp(Intensity, 0.0, 1.0);
    vec2 c = texCoord - 0.5;
    float aspect = InSize.x / InSize.y;
    vec2 ac = c * vec2(aspect, 1.0);
    float r = length(ac) + 1.0e-4;
    float a = atan(ac.y, ac.x);
    float lr = log(r);

    float z = lr * 3.0 - Clock * 3.5;
    float petals = 0.5 + 0.5 * cos(a * 9.0 + sin(z * 2.0) * 3.0 + Clock);
    float lattice = 0.5 + 0.5 * sin(z * 6.2831);
    float jewel = pow(petals * lattice, 1.5);
    float spokes = 0.5 + 0.5 * sin(a * 24.0 - z * 4.0);
    vec3 pc = hsv2rgb(vec3(fract(z * 0.15 + a / 6.2831 + Clock * 0.1), 0.85, 1.0)) * (0.25 + jewel * 1.3 + spokes * 0.2);

    vec2 wuv = 0.5 + c * (1.0 + I * 0.25 * sin(lr * 4.0 - Clock * 5.0));
    vec3 scene = tex(wuv);
    vec3 hsv = rgb2hsv(scene);
    hsv.x = fract(hsv.x + I * (Clock * 0.3 + r));
    scene = hsv2rgb(hsv);

    vec3 col = mix(scene, pc, smoothstep(0.15, 0.8, I));
    col += vec3(1.0) * (1.0 - smoothstep(0.0, 0.3, r)) * I * 0.6;
    col = mix(col, vec3(1.0), smoothstep(0.82, 1.0, I));
    fragColor = vec4(col, 1.0);
}
