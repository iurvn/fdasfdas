#version 150
uniform sampler2D DiffuseSampler;

in vec2 texCoord;
in vec2 oneTexel;
uniform vec2 InSize;
uniform float Clock;
uniform float Intensity;
out vec4 fragColor;

vec3 rgb2hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}
vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}
float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
float noise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p);
    float a = hash(i); float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0)); float d = hash(i + vec2(1.0, 1.0));
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}
vec3 tex(vec2 uv) { return texture(DiffuseSampler, clamp(uv, vec2(0.001), vec2(0.999))).rgb; }
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

void main() {
    float I = clamp(Intensity, 0.0, 1.5);
    vec2 uv = texCoord;
    uv += 0.003 * I * vec2(sin(uv.y * 6.0 + Clock * 0.6), cos(uv.x * 5.0 + Clock * 0.5));
    vec2 o = oneTexel * (1.0 + 2.0 * I);
    vec3 col = tex(uv) * 0.4;
    col += (tex(uv + vec2(o.x, 0.0)) + tex(uv - vec2(o.x, 0.0)) + tex(uv + vec2(0.0, o.y)) + tex(uv - vec2(0.0, o.y))) * 0.1;
    col += (tex(uv + o) + tex(uv - o) + tex(uv + vec2(o.x, -o.y)) + tex(uv + vec2(-o.x, o.y))) * 0.05;

    vec3 grade = col * vec3(1.02, 1.08, 0.88) + vec3(0.03, 0.05, 0.0);
    col = mix(col, grade, I * 0.8);
    col = mix(col, vec3(luma(col)), -0.25 * I);
    col += smoothstep(0.6, 1.0, luma(col)) * 0.15 * I;

    float lid = 0.07 * I + 0.05 * I * (0.5 + 0.5 * sin(Clock * 0.5));
    float e = smoothstep(lid, lid + 0.12, texCoord.y) * smoothstep(lid, lid + 0.12, 1.0 - texCoord.y);
    col *= mix(1.0, e, min(I, 1.0));
    col *= 1.0 - dot(texCoord - 0.5, texCoord - 0.5) * 1.4 * I;
    fragColor = vec4(col, 1.0);
}
