#version 150
uniform sampler2D DiffuseSampler;
uniform sampler2D PrevSampler;
in vec2 texCoord;
in vec2 oneTexel;
uniform vec2 InSize;
uniform float Clock;
uniform float Intensity;
out vec4 fragColor;

vec3 rgb2hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}
vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}
float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
float noise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p);
    float a = hash(i); float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0)); float d = hash(i + vec2(1.0, 1.0));
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}
vec3 tex(vec2 uv) { return texture(DiffuseSampler, clamp(uv, vec2(0.001), vec2(0.999))).rgb; }
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

void main() {
    float I = clamp(Intensity, 0.0, 1.5);
    vec2 uv = texCoord;
    vec2 c = uv - 0.5;
    float aspect = InSize.x / InSize.y;
    vec2 ac = vec2(c.x * aspect, c.y);
    float r = length(ac);
    float a = atan(ac.y, ac.x);

    float breathe = sin(Clock * 1.3) * 0.02 * I;
    vec2 wuv = uv + c * breathe + 0.006 * I * vec2(sin(uv.y * 25.0 + Clock * 2.1), cos(uv.x * 22.0 + Clock * 1.6));
    vec3 base = tex(wuv);

    float seg = 6.2831853 / 8.0;
    float ka = mod(a + Clock * 0.15, seg);
    ka = abs(ka - seg * 0.5);
    vec2 kc = vec2(cos(ka), sin(ka)) * r * (1.0 + 0.1 * sin(Clock));
    kc.x /= aspect;
    vec3 kal = tex(kc + 0.5);
    vec3 col = mix(base, kal, 0.4 * I * smoothstep(0.05, 0.45, r));

    vec3 hsv = rgb2hsv(col);
    hsv.x = fract(hsv.x + I * (Clock * 0.08 + r * 0.6 + 0.1 * sin(a * 3.0 + Clock)));
    hsv.y = clamp(hsv.y * (1.0 + 0.9 * I) + 0.15 * I, 0.0, 1.0);
    col = hsv2rgb(hsv);

    float rings = sin(r * 60.0 - Clock * 4.0) * 0.5 + 0.5;
    col += I * 0.07 * rings * hsv2rgb(vec3(fract(r * 2.0 - Clock * 0.2), 1.0, 1.0));

    vec3 prev = texture(PrevSampler, texCoord).rgb;
    col = mix(col, max(col, prev * 0.88), 0.6 * min(I, 1.0));
    fragColor = vec4(col, 1.0);
}
