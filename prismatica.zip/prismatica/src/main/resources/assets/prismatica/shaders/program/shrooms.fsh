#version 150
uniform sampler2D DiffuseSampler;
uniform sampler2D PrevSampler;
in vec2 texCoord;
in vec2 oneTexel;
uniform vec2 InSize;
uniform float Clock;
uniform float Intensity;
out vec4 fragColor;

vec3 rgb2hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}
vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}
float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
float noise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p);
    float a = hash(i); float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0)); float d = hash(i + vec2(1.0, 1.0));
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}
vec3 tex(vec2 uv) { return texture(DiffuseSampler, clamp(uv, vec2(0.001), vec2(0.999))).rgb; }
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

void main() {
    float I = clamp(Intensity, 0.0, 1.5);
    vec2 uv = texCoord;
    vec2 c = uv - 0.5;
    uv = 0.5 + c * (1.0 - 0.025 * I * sin(Clock * 0.9));

    float wave = (sin(uv.x * 14.0 + Clock * 0.7) * 0.5 + 0.5) * (sin(uv.x * 5.0 - Clock * 0.45) * 0.5 + 0.5);
    float drip = I * 0.045 * wave * (0.3 + uv.y);
    vec2 m = vec2(uv.x + 0.004 * I * sin(uv.y * 28.0 + Clock * 1.3), uv.y + drip);
    vec3 col = tex(m);

    float pat = sin(uv.x * 48.0 + sin(uv.y * 36.0 + Clock * 0.8) * 2.0) * sin(uv.y * 44.0 + sin(uv.x * 30.0 - Clock * 0.6) * 2.0);
    float L = luma(col);
    vec3 patCol = hsv2rgb(vec3(fract(L * 1.5 + Clock * 0.05), 0.7, 1.0));
    col = mix(col, col * 0.6 + patCol * 0.5, I * 0.2 * smoothstep(0.2, 1.0, pat));

    vec3 hsv = rgb2hsv(col);
    hsv.y = clamp(hsv.y * (1.0 + 0.7 * I), 0.0, 1.0);
    hsv.x = fract(hsv.x + 0.04 * I * sin(Clock * 0.4 + uv.y * 4.0));
    col = hsv2rgb(hsv);

    vec3 prev = texture(PrevSampler, texCoord).rgb;
    col = mix(col, max(col, prev * 0.93), 0.65 * min(I, 1.0));
    fragColor = vec4(col, 1.0);
}
