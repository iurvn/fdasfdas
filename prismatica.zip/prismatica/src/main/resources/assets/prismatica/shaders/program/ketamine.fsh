#version 150
uniform sampler2D DiffuseSampler;

in vec2 texCoord;
in vec2 oneTexel;
uniform vec2 InSize;
uniform float Clock;
uniform float Intensity;
out vec4 fragColor;

vec3 rgb2hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}
vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}
float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
float noise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p);
    float a = hash(i); float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0)); float d = hash(i + vec2(1.0, 1.0));
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}
vec3 tex(vec2 uv) { return texture(DiffuseSampler, clamp(uv, vec2(0.001), vec2(0.999))).rgb; }
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

void main() {
    float I = clamp(Intensity, 0.0, 1.5);
    vec2 c = texCoord - 0.5;
    float aspect = InSize.x / InSize.y;
    float r = length(c * vec2(aspect, 1.0));

    float pull = 1.0 + I * (0.35 + 0.1 * sin(Clock * 0.4)) * (1.0 - r);
    vec2 suv = 0.5 + c * pull;
    vec3 col = tex(suv);

    vec3 echo = tex(0.5 + c * pull * 1.8);
    float inner = 1.0 - smoothstep(0.18, 0.3, r);
    col = mix(col, echo, inner * 0.35 * I);

    vec3 ghost = tex(suv + vec2(0.012 * I * sin(Clock * 0.35), 0.006 * I));
    col = mix(col, ghost, 0.35 * min(I, 1.0));

    float rings = 0.5 + 0.5 * sin(log(r + 0.02) * 14.0 - Clock * 2.0);
    float tunnel = smoothstep(0.25, 0.75, r);
    col *= 1.0 - tunnel * min(I, 1.0) * (0.45 + 0.25 * rings);

    float L = luma(col);
    col = mix(col, vec3(L) * vec3(0.85, 0.95, 1.15), 0.65 * min(I, 1.0));
    fragColor = vec4(col, 1.0);
}
