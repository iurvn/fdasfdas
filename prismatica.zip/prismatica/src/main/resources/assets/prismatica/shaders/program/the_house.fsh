#version 150
uniform sampler2D DiffuseSampler;
uniform float Dread;
in vec2 texCoord;
in vec2 oneTexel;
uniform vec2 InSize;
uniform float Clock;
uniform float Intensity;
out vec4 fragColor;

vec3 rgb2hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}
vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}
float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
float noise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p);
    float a = hash(i); float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0)); float d = hash(i + vec2(1.0, 1.0));
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}
vec3 tex(vec2 uv) { return texture(DiffuseSampler, clamp(uv, vec2(0.001), vec2(0.999))).rgb; }
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

void main() {
    vec2 uv = texCoord;
    float D = clamp(Dread, 0.0, 1.0);

    float band = floor(uv.y * 40.0);
    float g = step(0.985 - D * 0.08, hash(vec2(band, floor(Clock * 12.0))));
    uv.x += g * (hash(vec2(band, Clock)) - 0.5) * 0.06 * (0.3 + D);

    float ca = 0.002 + 0.008 * D;
    vec3 col = vec3(tex(uv + vec2(ca, 0.0)).r, tex(uv).g, tex(uv - vec2(ca, 0.0)).b);

    float L = luma(col);
    col = mix(col, vec3(L), 0.75);
    col = pow(max(col, vec3(0.0)), vec3(1.25));
    col *= vec3(0.95, 0.92, 0.9);
    col *= 0.85 + 0.15 * noise(vec2(Clock * 6.0, 0.0));

    float beat = pow(abs(sin(Clock * 3.14159 * (1.0 + D))), 12.0);
    col *= 1.0 - 0.25 * D * beat;
    float edgeR = length(texCoord - 0.5);
    col += vec3(0.18, 0.0, 0.0) * D * beat * smoothstep(0.3, 0.8, edgeR);

    float len = length((texCoord - 0.5) * vec2(InSize.x / InSize.y, 1.0));
    col *= 1.0 - smoothstep(0.2, 0.85 - 0.35 * D, len);
    col += (hash(texCoord * InSize + fract(Clock) * 100.0) - 0.5) * 0.08;
    fragColor = vec4(col, 1.0);
}
