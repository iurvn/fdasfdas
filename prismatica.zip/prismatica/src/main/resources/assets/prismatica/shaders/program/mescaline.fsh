#version 150
uniform sampler2D DiffuseSampler;

in vec2 texCoord;
in vec2 oneTexel;
uniform vec2 InSize;
uniform float Clock;
uniform float Intensity;
out vec4 fragColor;

vec3 rgb2hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}
vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}
float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
float noise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p);
    float a = hash(i); float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0)); float d = hash(i + vec2(1.0, 1.0));
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}
vec3 tex(vec2 uv) { return texture(DiffuseSampler, clamp(uv, vec2(0.001), vec2(0.999))).rgb; }
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

vec4 hexCoords(vec2 p) {
    vec2 r = vec2(1.0, 1.7320508);
    vec2 h = r * 0.5;
    vec2 a = mod(p, r) - h;
    vec2 b = mod(p - h, r) - h;
    vec2 gv = dot(a, a) < dot(b, b) ? a : b;
    return vec4(gv, p - gv);
}
float hexDist(vec2 p) {
    p = abs(p);
    return max(dot(p, normalize(vec2(1.0, 1.7320508))), p.x);
}
void main() {
    float I = clamp(Intensity, 0.0, 1.5);
    vec2 uv = texCoord;
    vec2 c = uv - 0.5;
    float aspect = InSize.x / InSize.y;
    float r = length(c * vec2(aspect, 1.0));
    float ang = 0.15 * I * sin(Clock * 0.3) * (1.0 - r);
    float s = sin(ang); float co = cos(ang);
    vec2 sw = vec2(c.x * co - c.y * s, c.x * s + c.y * co) + 0.5;
    vec3 col = tex(sw);

    vec2 t = oneTexel;
    float tl = luma(tex(sw + vec2(-t.x, t.y)));  float tm = luma(tex(sw + vec2(0.0, t.y)));  float tr = luma(tex(sw + vec2(t.x, t.y)));
    float ml = luma(tex(sw + vec2(-t.x, 0.0)));                                                 float mr = luma(tex(sw + vec2(t.x, 0.0)));
    float bl = luma(tex(sw + vec2(-t.x, -t.y))); float bm = luma(tex(sw + vec2(0.0, -t.y))); float br = luma(tex(sw + vec2(t.x, -t.y)));
    float gx = -tl - 2.0 * ml - bl + tr + 2.0 * mr + br;
    float gy = -tl - 2.0 * tm - tr + bl + 2.0 * bm + br;
    float edge = clamp(length(vec2(gx, gy)) * 1.5, 0.0, 1.0);
    vec3 edgeCol = hsv2rgb(vec3(fract(Clock * 0.07 + sw.x * 0.8 + sw.y * 0.5), 0.9, 1.0));
    col += edgeCol * edge * 0.9 * I;

    vec2 hp = c * vec2(aspect, 1.0) * 14.0 + vec2(Clock * 0.2, Clock * 0.1);
    vec4 hc = hexCoords(hp);
    float line = smoothstep(0.43, 0.49, hexDist(hc.xy));
    float pulse = 0.5 + 0.5 * sin(Clock * 1.5 - length(hc.zw) * 0.6);
    vec3 hexCol = hsv2rgb(vec3(fract(length(hc.zw) * 0.05 + Clock * 0.05), 0.6, 1.0));
    col += hexCol * line * pulse * 0.22 * I;

    col = mix(col, col * vec3(1.12, 1.0, 0.82), 0.7 * min(I, 1.0));
    fragColor = vec4(col, 1.0);
}
